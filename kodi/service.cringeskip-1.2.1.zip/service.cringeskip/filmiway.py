"""Filmiway lookup for the CringeMDB Skip Kodi service.

Fallback scene source, used when CringeMDB has a movie but no
scene times (or no page at all). Filmiway (filmiway.com) publishes
free per-movie "skip timestamps" pages with hand-verified start
and end times for sex/nudity scenes; violence and profanity are
overall advisories there, never timed, so every timed scene this
module returns is in the sexual family.

Pure stdlib (no Kodi imports) so it can be unit-tested outside
Kodi. Transport and title cleaning are shared with cringemdb.py
(plain urllib with a DNS-over-HTTPS fallback).

find_guide(title, year) -> dict or None, same shape as
cringemdb.find_guide:
  {"slug": str, "not_safe": bool,
   "scenes": [{"start": int, "end": int, "category": str,
               "intensity": str, "desc": str}, ...]}

A page is located by slugifying the title
(filmiway.com/movie/<slug>/skip-timestamps); if that misses, the
site's movie sitemap (~600 titles) is scanned for an exact-title
slug. Either way the page itself must verify: the title embedded
in the page must equal the cleaned query title and the year must
match exactly — a one-year-off page is accepted only when it is
the single exact-title candidate, mirroring cringemdb.py, so a
remake can never be attached by mistake. Scene data is read from
the page's __NEXT_DATA__ JSON ("resolvedSensitiveScenes");
entries without real start/end seconds are untimed advisories
and are dropped.
"""
import json
import re
import urllib.error

import cringemdb

BASE = "https://www.filmiway.com"
SITEMAP = BASE + "/sitemap-movies.xml"

_cache = {}
_sitemap_slugs = None


def _slugify(title):
    """'A.I. Artificial Intelligence' -> 'a-i-artificial-intelligence'."""
    return re.sub(r"[^a-z0-9]+", "-", (title or "").lower()).strip("-")


def _fetch(url):
    """(text, error). A 404 is a clean miss: (None, None). Any
    other failure is (None, exception) so the caller can tell a
    network problem from a movie that simply is not listed."""
    try:
        return cringemdb.http_get(url), None
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None, None
        return None, e
    except Exception as e:
        return None, e


def _find_key(obj, key):
    if isinstance(obj, dict):
        if key in obj:
            return obj[key]
        for v in obj.values():
            r = _find_key(v, key)
            if r is not None:
                return r
    elif isinstance(obj, list):
        for v in obj:
            r = _find_key(v, key)
            if r is not None:
                return r
    return None


def _parse_page(html_text, slug):
    """(page_title, page_year, scenes) or None when the page does
    not carry the expected data block."""
    m = re.search(r'<script id="__NEXT_DATA__" type="application/json">'
                  r"(.*?)</script>", html_text, re.S)
    if not m:
        return None
    try:
        data = json.loads(m.group(1))
    except Exception:
        return None
    props = _find_key(data, "pageProps")
    movie = (props or {}).get("movie") or {}
    page_title = movie.get("Title") or ""
    try:
        page_year = int(movie.get("year"))
    except (TypeError, ValueError):
        page_year = None
    if not page_title:
        return None
    scenes = []
    for s in _find_key(data, "resolvedSensitiveScenes") or []:
        if not isinstance(s, dict):
            continue
        start, end = s.get("startSec"), s.get("endSec")
        if not isinstance(start, int) or not isinstance(end, int):
            continue  # untimed advisory (violence / profanity)
        if end <= start:
            continue
        scenes.append({"start": start, "end": end,
                       "category": s.get("type") or "",
                       "intensity": s.get("severity") or "",
                       "desc": s.get("description") or ""})
    scenes.sort(key=lambda s: s["start"])
    return page_title, page_year, scenes


def _sitemap():
    """All movie slugs from the sitemap, fetched once per session.
    Returns None when the sitemap cannot be fetched."""
    global _sitemap_slugs
    if _sitemap_slugs is not None:
        return _sitemap_slugs
    text, err = _fetch(SITEMAP)
    if text is None:
        return None
    _sitemap_slugs = re.findall(r"/movie/([^/<]+)/skip-timestamps", text)
    return _sitemap_slugs


def _title_variants(title):
    """Cleaned titles a de-slugged sitemap entry may match."""
    variants = {cringemdb.clean_title(title)}
    if "&" in (title or ""):
        variants.add(cringemdb.clean_title(title.replace("&", " and ")))
    return variants


def _candidate_slugs(title):
    """Sitemap slugs whose de-slugged title equals the query."""
    slugs = _sitemap()
    if not slugs:
        return []
    variants = _title_variants(title)
    return [s for s in slugs
            if cringemdb.clean_title(s.replace("-", " ")) in variants]


def find_guide(title, year):
    for attempt_title, attempt_year in cringemdb._title_attempts(title, year):
        guide = _find_guide_strict(attempt_title, attempt_year)
        if guide is not None:
            return guide
    return None


def _find_guide_strict(title, year):
    key = (cringemdb.clean_title(title), year)
    if key in _cache:
        return _cache[key]
    cleaned = cringemdb.clean_title(title)
    last_error = None
    pages = {}  # slug -> (page_title, page_year, scenes)

    def load(slug):
        if slug in pages:
            return pages[slug]
        text, err = _fetch(BASE + "/movie/" + slug + "/skip-timestamps")
        if err is not None:
            nonlocal_error(err)
            pages[slug] = None
            return None
        pages[slug] = _parse_page(text, slug) if text else None
        return pages[slug]

    def nonlocal_error(err):
        nonlocal last_error
        last_error = err

    # 1) Direct slug guess.
    direct = _slugify(title)
    parsed = load(direct)
    if _matches(parsed, cleaned, year):
        return _finish(key, direct, parsed)
    # 2) Sitemap candidates with the exact title: prefer an exact
    #    year match; a single one-year-off candidate is accepted
    #    when no exact-year candidate exists (cringemdb's rule).
    cands = []
    for slug in _candidate_slugs(title):
        if slug == direct:
            p = parsed
        else:
            p = load(slug)
        if p and cringemdb.clean_title(p[0]) == cleaned:
            cands.append((slug, p))
    for slug, p in cands:
        if year is None or p[1] == year:
            return _finish(key, slug, p)
    if year is not None:
        near = [(slug, p) for slug, p in cands
                if p[1] is not None and abs(p[1] - year) == 1]
        if len(near) == 1:
            return _finish(key, near[0][0], near[0][1])
    if not cands and last_error is not None:
        raise last_error
    _cache[key] = None
    return None


def _matches(parsed, cleaned, year):
    if not parsed:
        return False
    if cringemdb.clean_title(parsed[0]) != cleaned:
        return False
    return year is None or parsed[1] == year


def _finish(key, slug, parsed):
    scenes = parsed[2]
    guide = {"slug": slug, "not_safe": len(scenes) > 0,
             "scenes": scenes, "source": "filmiway"}
    _cache[key] = guide
    return guide
