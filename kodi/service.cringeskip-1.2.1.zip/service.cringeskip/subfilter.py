"""Subtitle word filter for the CringeMDB Skip service.

Pure stdlib (no Kodi imports) so it can be unit-tested outside Kodi.

Kodi gives addons no hook into its subtitle renderer, so the
service works on subtitle FILES: when a subtitle addon downloads
an .srt/.ass/.vtt for the playing movie, service.py makes a
filtered copy with this module and swaps playback to the copy via
xbmc.Player.setSubtitles(). Embedded or burned-in subtitles cannot
be touched.

Masking: each listed word is matched at a word boundary together
with any word characters that follow it, case-insensitively, and
the whole token is replaced by "****" — so the list entry "kiss"
also hides "kissing" and "kissed", and "sex" hides "sexy"/"sexual"
(and, as accepted collateral for a kids filter, a word like
"Sexton"). Timing lines, cue numbers and markup tags are never
modified, so the filtered file keeps the original sync.
"""
import re

MASK = "****"


def parse_words(text):
    """'fuck, sex, kiss' -> ['fuck', 'sex', 'kiss'] (lowercased,
    de-duplicated, empties dropped)."""
    words = []
    for w in re.split(r"[,\n;]+", text or ""):
        w = w.strip().lower()
        if w and w not in words:
            words.append(w)
    return words


def build_pattern(words):
    if not words:
        return None
    parts = sorted((re.escape(w) for w in words),
                   key=len, reverse=True)
    return re.compile(r"\b(?:%s)\w*" % "|".join(parts), re.IGNORECASE)


def mask_plain(text, pattern):
    """Mask listed words in plain caption text (no markup)."""
    return pattern.subn(MASK, text)


_TAG_SPLIT = re.compile(r"(<[^>]+>|\{[^}]*\})")


def mask_rich(text, pattern):
    """Mask caption text that may contain markup: <i> tags in SRT,
    {override} blocks in ASS. Markup itself is left untouched."""
    parts = _TAG_SPLIT.split(text)
    count = 0
    for i, part in enumerate(parts):
        if part.startswith("<") or part.startswith("{"):
            continue
        parts[i], n = pattern.subn(MASK, part)
        count += n
    return "".join(parts), count


# ---------------------------------------------------------------------------
# Format filters. Each returns (new_text, masked_word_count).
# ---------------------------------------------------------------------------

_SRT_TIMING = re.compile(r"^\d{2}:\d{2}:\d{2}[,.]\d+\s+-->\s+")


def filter_srt(text, pattern):
    out = []
    count = 0
    for line in text.splitlines():
        stripped = line.strip()
        if (not stripped or stripped.isdigit()
                or _SRT_TIMING.match(stripped)):
            out.append(line)
            continue
        new, n = mask_rich(line, pattern)
        out.append(new)
        count += n
    return "\n".join(out) + ("\n" if text.endswith("\n") else ""), count


def filter_ass(text, pattern):
    out = []
    count = 0
    for line in text.splitlines():
        if line.startswith("Dialogue:"):
            # Text is everything after the 9th comma.
            parts = line.split(",", 9)
            if len(parts) == 10:
                new, n = mask_rich(parts[9], pattern)
                parts[9] = new
                count += n
                line = ",".join(parts)
        out.append(line)
    return "\n".join(out) + ("\n" if text.endswith("\n") else ""), count


_VTT_TIMING = re.compile(r"^\d{2}:\d{2}[:.]\d{2}")


def filter_vtt(text, pattern):
    out = []
    count = 0
    in_block = None  # NOTE / STYLE / REGION blocks pass through
    for i, line in enumerate(text.splitlines()):
        stripped = line.strip()
        upper = stripped.upper()
        if i == 0 and upper.startswith("WEBVTT"):
            out.append(line)
            continue
        if upper.startswith(("NOTE", "STYLE", "REGION")):
            in_block = True
        if in_block:
            out.append(line)
            if not stripped:
                in_block = None
            continue
        if (not stripped or "-->" in line
                or _VTT_TIMING.match(stripped)):
            out.append(line)
            continue
        new, n = mask_rich(line, pattern)
        out.append(new)
        count += n
    return "\n".join(out) + ("\n" if text.endswith("\n") else ""), count


def filter_subtitle(text, ext, words):
    """Dispatch by file extension ('.srt' / '.ass' / '.ssa' /
    '.vtt'). Returns (new_text, count); unknown formats and empty
    word lists return the text unchanged with count 0."""
    pattern = build_pattern(words)
    if pattern is None:
        return text, 0
    ext = (ext or "").lower()
    if ext == ".srt":
        return filter_srt(text, pattern)
    if ext in (".ass", ".ssa"):
        return filter_ass(text, pattern)
    if ext == ".vtt":
        return filter_vtt(text, pattern)
    return text, 0


def decode_subtitle(data):
    """Subtitle bytes -> text (UTF-8 with BOM preferred, Latin-1
    as the never-fail fallback)."""
    for enc in ("utf-8-sig", "utf-8", "cp1252"):
        try:
            return data.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return data.decode("latin-1", "replace")
