"""CringeMDB Skip — Kodi service.

Watches whatever video is playing, identifies the movie (title +
year from the player's info, with a filename-parse fallback),
looks up its flagged scenes on CringeMDB, and automatically seeks
past them — a ClearPlay-style skip for streams, driven by
CringeMDB's community scene data.

Scene times come from other releases, so they can be off by a few
seconds on a given stream; the lead-seconds setting pads the start
of each skip. A range is skipped at most once per playback — if
you seek back into it on purpose, it plays.
"""
import json
import sys
import threading

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon("service.cringeskip")
# Make sure this addon's own folder is importable — it is not on
# sys.path in every Kodi service context, and a failed import
# would kill the service silently at startup.
sys.path.insert(0, ADDON.getAddonInfo("path"))

import cringemdb
LOG_PREFIX = "[service.cringeskip] "


def log(msg):
    xbmc.log(LOG_PREFIX + msg, xbmc.LOGINFO)


def notify(text):
    try:
        xbmcgui.Dialog().notification(
            "CringeMDB Skip", text, ADDON.getAddonInfo("icon"), 3500, False)
    except Exception:
        pass


def debug_notify(text):
    """Progress announcements while we shake the service down."""
    try:
        if ADDON.getSettingBool("debug"):
            notify(text)
    except Exception:
        pass


def player_item():
    """The playing item's metadata via JSON-RPC (title/year/label)."""
    try:
        res = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1,
            "method": "Player.GetActivePlayers", "params": {}})))
        pid = next((p["playerid"] for p in res.get("result", [])
                    if p.get("type") == "video"), None)
        if pid is None:
            return {}
        res = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "Player.GetItem",
            "params": {"playerid": pid,
                       "properties": ["title", "year", "label"]}})))
        return res.get("result", {}).get("item", {}) or {}
    except Exception:
        return {}


def seek_to(player, seconds):
    """Absolute seek (seconds). Verifies the JSON-RPC result —
    an RPC error reply is NOT a successful seek — and falls back
    to the player object's own seek. Returns (ok, how)."""
    seconds = max(0, int(round(seconds)))
    try:
        active = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1,
            "method": "Player.GetActivePlayers", "params": {}})))
        players = active.get("result", [])
        pid = next((p["playerid"] for p in players
                    if p.get("type") == "video"),
                   players[0]["playerid"] if players else 1)
        h, rem = divmod(seconds, 3600)
        m, s = divmod(rem, 60)
        resp = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "Player.Seek",
            "params": {"playerid": pid, "value": {
                "hours": h, "minutes": m, "seconds": s,
                "milliseconds": 0}}})))
        if resp.get("result") == "OK" and "error" not in resp:
            return True, "rpc"
        log("seek RPC not OK: %r" % (resp,))
    except Exception as e:
        log("seek RPC failed: %r" % (e,))
    try:
        player.seekTime(float(seconds))
        return True, "seekTime"
    except Exception as e:
        log("seekTime failed: %r" % (e,))
        return False, "none"


def lead_seconds():
    """The lead setting, read defensively (slider storage has
    varied across Kodi versions; never let it kill the cycle)."""
    try:
        return ADDON.getSettingInt("lead_seconds")
    except Exception:
        pass
    try:
        return int(ADDON.getSetting("lead_seconds"))
    except Exception:
        return 2


class SkipService:
    def __init__(self):
        self.key = None          # (file, title, year) being tracked
        self.ranges = []         # prepared skip ranges for self.key
        self.lookup_state = "idle"   # idle | working | done
        self._unidentified_file = None
        self._pending_verify = None  # (range, attempts) after a seek
        self._lock = threading.Lock()

    # ------------------------------------------------------------ lookup
    def _start_lookup(self, title, year):
        self.lookup_state = "working"

        def work():
            guide = None
            error = None
            try:
                guide = cringemdb.find_guide(title, year)
            except Exception as e:
                error = e
                log("lookup failed for %r (%r): %r" % (title, year, e))
            ranges = []
            if guide and guide.get("not_safe"):
                skip_sexual = ADDON.getSettingBool("skip_sexual")
                skip_violence = ADDON.getSettingBool("skip_violence")
                chosen = []
                for s in guide["scenes"]:
                    if cringemdb.is_sexual(s["category"]) and not skip_sexual:
                        continue
                    if cringemdb.is_violence(s["category"]) and not skip_violence:
                        continue
                    chosen.append(s)
                # Merge overlapping / near-identical ranges (the
                # source sometimes lists a scene twice).
                for s in sorted(chosen, key=lambda x: x["start"]):
                    if ranges and s["start"] <= ranges[-1]["end"] + 2:
                        ranges[-1]["end"] = max(ranges[-1]["end"], s["end"])
                    else:
                        ranges.append({"start": s["start"], "end": s["end"],
                                       "category": s["category"],
                                       "done": False})
                log("guide for %r (%r): %d scenes -> %d skip ranges"
                    % (title, year, len(guide["scenes"]), len(ranges)))
            elif guide:
                log("guide for %r (%r): SAFE, nothing to skip" % (title, year))
            else:
                log("no CringeMDB guide for %r (%r)" % (title, year))
            with self._lock:
                self.ranges = ranges
                self.lookup_state = "done"
            if error is not None:
                debug_notify("Lookup failed: %s" % type(error).__name__)
            elif guide is None:
                debug_notify("No CringeMDB guide for %s" % title)
            elif not guide.get("not_safe"):
                debug_notify("%s: SAFE on CringeMDB" % title)
            elif ranges:
                debug_notify("%s: %d scene(s) will be skipped"
                             % (title, len(ranges)))
            else:
                try:
                    states = "sex=%s violence=%s" % (
                        ADDON.getSettingBool("skip_sexual"),
                        ADDON.getSettingBool("skip_violence"))
                except Exception:
                    states = "settings unreadable"
                debug_notify("%s: guide found, no scenes armed (%s)"
                             % (title, states))

        threading.Thread(target=work, daemon=True).start()

    # ------------------------------------------------------------ cycle
    def cycle(self, player):
        if not ADDON.getSettingBool("enabled"):
            return
        if not player.isPlayingVideo():
            if self.key is not None:
                self.key = None
                self.ranges = []
                self.lookup_state = "idle"
            return

        title = (xbmc.getInfoLabel("VideoPlayer.Title") or "").strip()
        year_raw = (xbmc.getInfoLabel("VideoPlayer.Year") or "").strip()
        try:
            year = int(year_raw) if year_raw else None
        except ValueError:
            year = None
        try:
            playing_file = player.getPlayingFile()
        except Exception:
            playing_file = ""

        if not title or year is None:
            item = player_item()
            if not title:
                title = (item.get("title") or item.get("label")
                         or "").strip()
            if year is None and item.get("year"):
                try:
                    year = int(item["year"])
                except Exception:
                    pass
        if not title:
            parsed = cringemdb.parse_filename(playing_file)
            if parsed:
                title, year = parsed
        if not title:
            if self._unidentified_file != playing_file:
                self._unidentified_file = playing_file
                debug_notify("Could not identify this movie")
            return

        key = (playing_file, cringemdb.clean_title(title), year)
        if key != self.key:
            self.key = key
            self.ranges = []
            debug_notify("Watching: %s (%s)"
                         % (title, year if year else "?"))
            self._start_lookup(title, year)
            return
        if self.lookup_state != "done" or not self.ranges:
            return

        try:
            t = player.getTime()
        except Exception:
            return
        # A seek that was accepted but didn't take (seen with
        # some HLS streams): if we are still inside the scene a
        # few seconds later, try the other seek method, twice.
        if self._pending_verify is not None:
            r, attempts = self._pending_verify
            if t >= r["end"]:
                self._pending_verify = None
            elif attempts < 2:
                ok, how = seek_to(player, r["end"] + 1)
                log("verify: still in scene at t=%.0f, retry %d -> %s"
                    % (t, attempts + 1, how))
                self._pending_verify = (r, attempts + 1)
            else:
                debug_notify("Seek is not taking on this stream")
                self._pending_verify = None
            return
        lead = lead_seconds()
        for r in self.ranges:
            if r["done"]:
                continue
            if r["start"] - lead <= t < r["end"]:
                r["done"] = True
                debug_notify("Skipping now: %s scene" % r["category"])
                ok, how = seek_to(player, r["end"] + 1)
                if ok:
                    log("skipped %s scene %d-%ds at t=%.0f via %s"
                        % (r["category"], r["start"], r["end"], t, how))
                    if ADDON.getSettingBool("notify"):
                        notify("Skipped: %s scene" % r["category"])
                    self._pending_verify = (r, 0)
                else:
                    debug_notify("Seek failed for %s scene"
                                 % r["category"])
                break


def main():
    monitor = xbmc.Monitor()
    player = xbmc.Player()
    service = SkipService()
    log("service started")
    while not monitor.abortRequested():
        try:
            service.cycle(player)
        except Exception as e:
            log("cycle error: %r" % (e,))
        if monitor.waitForAbort(0.5):
            break
    log("service stopped")


if __name__ == "__main__":
    main()
