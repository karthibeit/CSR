"""OlaMovies (v6.olamovies.mov) site access for the OLA Kodi addon.

The site is a Next.js app. Listing pages render cards server-side;
detail pages embed a structured JSON model of the download sections
(seasons -> sources -> release blocks -> files/episodes/packs) inside
the React Server Components payload. This module extracts both with
plain string work (no HTML parser dependency) plus a resolver for the
links.ol-am.top shortener chain.
"""
import html as _html
import json
import re
import urllib.error
import urllib.parse
import urllib.request

BASE = "https://v6.olamovies.mov"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0 Safari/537.36")

CATEGORIES = [
    ("movies", "Movies"),
    ("tv-series", "TV Series"),
    ("tv-shows", "TV Shows"),
    ("south-indian", "South Indian"),
    ("south-tv-series", "South Indian TV Series"),
    ("bollywood", "Bollywood"),
    ("hollywood", "Hollywood"),
    ("hindi-tv-series", "Hindi TV Series"),
    ("hindi-tv-shows", "Hindi TV Shows"),
    ("english-tv-series", "English TV Series"),
    ("korean-movies", "Korean Movies"),
    ("korean-tv-series", "Korean TV Series"),
    ("chinese-movies", "Chinese Movies"),
    ("chinese-tv-series", "Chinese TV Series"),
    ("japanese-movies", "Japanese Movies"),
    ("anime-movies", "Anime Movies"),
    ("anime-tv-series", "Anime TV Series"),
    ("bangla", "Bangla"),
    ("bangla-tv-series", "Bangla TV Series"),
    ("documentary", "Documentary"),
    ("documentary-movies", "Documentary Movies"),
    ("cartoon-tvs", "Cartoon TV"),
    ("short-films", "Short Films"),
    ("award-shows", "Award Shows"),
    ("specials-tv-shows", "Specials (TV)"),
    ("talk-shows", "Talk Shows"),
    ("standup-tours-and-concerts", "Standup, Tours & Concerts"),
    ("survival", "Survival"),
    ("other", "Other Movies"),
    ("other-tv-series", "Other TV Series"),
]


def fetch(url):
    req = urllib.request.Request(url, headers={
        "User-Agent": UA,
        "Accept": "text/html,application/xhtml+xml,*/*",
        "Accept-Language": "en-US,en;q=0.9",
    })
    with urllib.request.urlopen(req, timeout=30) as resp:
        return resp.read().decode("utf-8", "replace")


# ---------------------------------------------------------------------------
# Title cleanup — release titles carry the quality/codec junk after the
# name and year; keep "Name (Year)" when a year is present.
# ---------------------------------------------------------------------------

def clean_title(full):
    full = re.sub(r"\s+", " ", full or "").strip()
    full = re.sub(r"^(\[[^\]]*\]\s*)+", "", full)  # [Complete] etc.
    m = re.match(r"^(.*?)\(((?:19|20)\d{2})(?:\s*[-–]\s*(?:19|20)\d{2})?\)",
                 full)
    if m:
        return "%s (%s)" % (m.group(1).strip(), m.group(2))
    # No parenthesised year: cut at the first quality marker.
    m = re.match(r"^(.*?)\s+(?:19|20)\d{2}\b", full)
    if m and len(m.group(1)) >= 2:
        name = m.group(1).strip()
        year = re.search(r"(?:19|20)\d{2}", full).group(0)
        return "%s (%s)" % (name, year)
    cut = re.split(
        r"\s+(?:480p|576p|720p|1080p|2160p|4K|BluRay|WEB-DL|WEBRip|HDRip|"
        r"BRRip|DVDRip|x264|x265|HEVC|H\.?264|H\.?265)\b", full, maxsplit=1)
    return cut[0].strip() or full


def year_of(title):
    m = re.search(r"\((?:19|20)\d{2}\)", title or "")
    if m:
        return int(m.group(0)[1:5])
    m = re.search(r"\b(?:19|20)\d{2}\b", title or "")
    return int(m.group(0)) if m else None


# ---------------------------------------------------------------------------
# Listing cards
# ---------------------------------------------------------------------------

_CARD_RE = re.compile(
    r'<a[^>]+href="/(movies|tv-series)/([^"#]+)"[^>]*>(.*?)</a>',
    re.DOTALL)
_TAG_RE = re.compile(r"<[^>]+>")
_NEXTIMG_RE = re.compile(r"/_next/image\?url=([^&\"']+)")
_IMG_RE = re.compile(r'src="(https://img\.ol-am\.top/[^"]+)"')


def _card_title(block):
    text = _html.unescape(_TAG_RE.sub("\n", block))
    chunks = [re.sub(r"\s+", " ", c).strip() for c in text.split("\n")]
    chunks = [c for c in chunks if len(c) >= 8]
    if not chunks:
        return ""
    # The post title is by far the longest text chunk in a card.
    return max(chunks, key=len)


def parse_cards(html_text):
    """Return [{url, kind, slug, title, poster}] in page order."""
    items = []
    seen = set()
    for kind, slug, block in _CARD_RE.findall(html_text):
        url = "%s/%s/%s" % (BASE, kind, slug)
        if url in seen:
            continue
        seen.add(url)
        poster = ""
        m = _NEXTIMG_RE.search(block)
        if m:
            poster = urllib.parse.unquote(m.group(1))
        else:
            m = _IMG_RE.search(block)
            if m:
                poster = m.group(1)
            else:
                m = re.search(
                    r"background-image:\s*url\((https://img\.ol-am\.top/"
                    r"[^)\"']+)", block)
                if m:
                    poster = m.group(1)
        if not poster:
            # Every page's navigation carries a "Collections" panel
            # of plain text links to the same 13 collection posts.
            # Real post cards always carry a poster image; text-only
            # anchors are menus, not listings — skip them, otherwise
            # every folder shows the same menu links first.
            continue
        title = _card_title(block)
        if not title:
            title = slug.replace("-", " ").title()
        items.append({"url": url, "kind": kind, "slug": slug,
                      "title": title, "poster": poster})
    return items


def list_url(kind, slug=None, page=1, query=None):
    if query is not None:
        url = BASE + "/search?q=" + urllib.parse.quote_plus(query)
    elif kind == "home":
        url = BASE + "/"
    elif kind == "tag":
        url = "%s/tags/%s" % (BASE, slug)
    else:
        url = "%s/categories/%s" % (BASE, slug)
    if page and page > 1:
        url += ("&" if "?" in url else "?") + "page=%d" % page
    return url


# ---------------------------------------------------------------------------
# Detail pages — meta + the embedded sections model
# ---------------------------------------------------------------------------

def _meta(html_text, prop):
    m = re.search(
        r'property="%s" content="([^"]*)"' % re.escape(prop), html_text)
    if not m:
        m = re.search(
            r'content="([^"]*)" property="%s"' % re.escape(prop), html_text)
    if not m:
        return ""
    return (m.group(1).replace("&amp;", "&").replace("&#x27;", "'")
            .replace("&quot;", '"').strip())


def _rsc_text(html_text):
    """Reassemble the React Server Components payload.

    The page streams its data model as many
    self.__next_f.push([1, "..."]) script chunks; a big structure
    (the download sections) can span several chunks, so the chunk
    strings must be decoded and concatenated before the model can be
    read as one text.
    """
    parts = []
    decoder = json.JSONDecoder()
    for m in re.finditer(r"__next_f\.push\(\[1,", html_text):
        i = m.end()
        while i < len(html_text) and html_text[i] in " \t":
            i += 1
        if i < len(html_text) and html_text[i] == '"':
            try:
                s, _ = decoder.raw_decode(html_text[i:])
                if isinstance(s, str):
                    parts.append(s)
            except Exception:
                pass
    return "\n".join(parts)


def _extract_sections(html_text):
    """Pull the download "sections" JSON array out of the RSC payload.

    Returns a list of section dicts, or [] when the payload cannot be
    understood (the caller then falls back to a flat link scan).
    """
    text = _rsc_text(html_text) or html_text.replace('\\"', '"')
    for m in re.finditer(r'"sections":\[', text):
        start = m.end() - 1
        depth = 0
        in_str = False
        esc = False
        for i in range(start, len(text)):
            ch = text[i]
            if in_str:
                if esc:
                    esc = False
                elif ch == "\\":
                    esc = True
                elif ch == '"':
                    in_str = False
            else:
                if ch == '"':
                    in_str = True
                elif ch == "[":
                    depth += 1
                elif ch == "]":
                    depth -= 1
                    if depth == 0:
                        blob = text[start:i + 1]
                        if "links.ol-am.top" in blob:
                            try:
                                data = json.loads(blob)
                                if isinstance(data, list):
                                    return data
                            except Exception:
                                pass
                        break
    return []


_FILE_KEYS = ("files", "episodes", "packs")


def _file_item(raw, context):
    label = raw.get("label") or ""
    filename = raw.get("filename") or label
    return {
        "url": raw.get("url") or "",
        "label": label,
        "filename": filename,
        "filesize": raw.get("filesize") or "",
        "episode": raw.get("episode"),
        "broken": bool(raw.get("broken")),
        "context": context,
    }


def _block_items(block, context):
    out = []
    heading = block.get("heading") or ""
    # A block of plain files can mix several quality variants, and
    # each file's label already states its quality — so files keep
    # the plain context. Episode/pack blocks are one release each,
    # where the block's resolution/specs are what tell two releases
    # of the same episode apart, so they join the context.
    detail = " ".join(p for p in (block.get("resolution") or "",
                                  " ".join(block.get("specs") or []))
                      if p).strip()
    ctx_rich = (context + " · " + detail) if (context and detail) \
        else (context or detail)
    for key in _FILE_KEYS:
        ctx = ctx_rich if key in ("episodes", "packs") else context
        for raw in block.get(key) or []:
            if isinstance(raw, dict) and raw.get("url"):
                item = _file_item(raw, ctx)
                if key == "packs":
                    item["label"] = (item["label"] or "Season pack")
                    item["context"] = ctx
                if heading and key != "episodes":
                    item["heading"] = heading
                out.append(item)
    return out


def parse_detail(html_text, own_url=None):
    """Return {title, poster, plot, is_series, seasons, files, children}.

    seasons: [{label, items:[file...]}] for series pages.
    files: flat [file...] for movie pages (and series fallback).
    children: [card...] for collection/index posts, which carry no
    downloads of their own and instead link to each member post.
    """
    full_title = _meta(html_text, "og:title")
    title = clean_title(full_title)
    poster = _meta(html_text, "og:image")
    plot = _meta(html_text, "og:description")
    sections = _extract_sections(html_text)
    seasons = []
    files = []
    for sec in sections:
        if not isinstance(sec, dict):
            continue
        label = sec.get("label") or ""
        season_no = sec.get("season")
        items = []
        for block in sec.get("blocks") or []:
            if isinstance(block, dict):
                items.extend(_block_items(block, label))
        for src in sec.get("sources") or []:
            if not isinstance(src, dict):
                continue
            src_label = src.get("label") or ""
            ctx = ("Season %s · %s" % (season_no, src_label)
                   if season_no else src_label)
            for block in src.get("blocks") or []:
                if isinstance(block, dict):
                    items.extend(_block_items(block, ctx))
        if season_no:
            seasons.append({"label": label or ("Season %s" % season_no),
                            "season": season_no, "items": items})
        else:
            files.extend(items)
    if not files and not seasons:
        files = _flat_scan(html_text)
    children = []
    if not files and not seasons:
        # Collection/index post: no downloads of its own — its body
        # cards link to the member posts that carry the files.
        children = [c for c in parse_cards(html_text)
                    if c["url"] != own_url]
    is_series = bool(seasons)
    return {"title": title, "full_title": full_title, "poster": poster,
            "plot": plot, "is_series": is_series, "seasons": seasons,
            "files": files, "children": children,
            "year": year_of(full_title)}


_FLAT_RE = re.compile(
    r'\{"id":"itm_[^"]+","btnId":"[^"]*","url":"(https://links\.ol-am\.top/'
    r'[^"]+)","label":"([^"]*)"(?:,"episode":(\d+|null))?,"filename":"'
    r'([^"]*)","filesize":"([^"]*)","broken":(true|false)')


def _flat_scan(html_text):
    text = _rsc_text(html_text) or html_text.replace('\\"', '"')
    out = []
    seen = set()
    for url, label, ep, filename, size, broken in _FLAT_RE.findall(text):
        if url in seen:
            continue
        seen.add(url)
        out.append({"url": url, "label": label, "filename": filename,
                    "filesize": size,
                    "episode": int(ep) if ep and ep != "null" else None,
                    "broken": broken == "true", "context": ""})
    return out


# ---------------------------------------------------------------------------
# Shortener resolution
# ---------------------------------------------------------------------------

_VIDEO_EXT = (".mkv", ".mp4", ".avi", ".m4v", ".ts", ".mov", ".wmv",
              ".webm")
_DRIVE_RE = re.compile(r"drive\.google\.com/file/d/([A-Za-z0-9_-]+)")
_DRIVE_LINK_RE = re.compile(
    r"https://drive\.google\.com/(?:file/d/[A-Za-z0-9_-]+|open\?id="
    r"[A-Za-z0-9_-]+)[^\s\"'<>]*")
_HREF_RE = re.compile(r'href="(https?://[^"]+)"')


class ResolveError(Exception):
    pass


def _opener():
    return urllib.request.build_opener(
        urllib.request.HTTPRedirectHandler(),
        urllib.request.HTTPCookieProcessor())


def _get(opener, url):
    req = urllib.request.Request(url, headers={
        "User-Agent": UA, "Accept": "*/*",
        "Accept-Language": "en-US,en;q=0.9"})
    return opener.open(req, timeout=30)


def drive_download_url(file_id):
    return "https://drive.google.com/uc?export=download&id=" + file_id


def resolve_link(url):
    """Follow the shortener chain to something Kodi can play.

    Returns (kind, value):
      ("file", direct_url)      — play it as-is
      ("choices", [urls])       — landing page with several candidates
    Raises ResolveError with a plain-language reason otherwise.
    """
    opener = _opener()
    try:
        resp = _get(opener, url)
    except urllib.error.URLError as e:
        raise ResolveError(_unreachable_reason(url, e))
    except Exception as e:
        raise ResolveError(_unreachable_reason(url, e))
    final = resp.geturl()
    ctype = (resp.headers.get("Content-Type") or "").lower()
    path = urllib.parse.urlparse(final).path.lower()
    if path.endswith(_VIDEO_EXT) or ctype.startswith("video/"):
        resp.close()
        return ("file", final)
    m = _DRIVE_RE.search(final)
    if m:
        resp.close()
        return ("file", _drive_final(opener, m.group(1)))
    body = ""
    if "html" in ctype or not ctype:
        try:
            body = resp.read().decode("utf-8", "replace")
        except Exception:
            body = ""
    resp.close()
    if body:
        found = _scan_landing(body, final)
        if found:
            if len(found) == 1:
                return ("file", found[0]) \
                    if not found[0].startswith("DRIVE:") \
                    else ("file", _drive_final(opener, found[0][6:]))
            return ("choices", found)
    raise ResolveError(
        "No playable file was found at the end of this link "
        "(landed on %s)." % urllib.parse.urlparse(final).netloc)


def _unreachable_reason(url, err):
    reason = getattr(err, "reason", err)
    text = str(reason).lower()
    if "name or service not known" in text or "temporary failure" in text \
            or "dns" in text or "getaddrinfo" in text \
            or "no address associated" in text or "errno 7" in text \
            or "nodename nor servname" in text \
            or "remote end closed" in text or "connection reset" in text:
        return ("The site's link host could not be reached — its "
                "address does not resolve right now. This is a problem "
                "on the OlaMovies side; the downloads work again once "
                "they fix it.")
    return "The link could not be opened: %s" % (reason,)


def _drive_final(opener, file_id):
    """Best-effort: turn a Drive file id into a streamable URL."""
    url = drive_download_url(file_id)
    try:
        resp = _get(opener, url)
        ctype = (resp.headers.get("Content-Type") or "").lower()
        final = resp.geturl()
        if ctype.startswith("video/") or "octet-stream" in ctype:
            resp.close()
            return final
        body = resp.read().decode("utf-8", "replace")
        resp.close()
        m = re.search(r"confirm=([0-9A-Za-z_-]+)", body)
        if m:
            return url + "&confirm=" + m.group(1)
    except Exception:
        pass
    return url


def _scan_landing(body, base_url):
    out = []
    for link in _DRIVE_LINK_RE.findall(body):
        m = _DRIVE_RE.search(link)
        if m:
            tag = "DRIVE:" + m.group(1)
            if tag not in out:
                out.append(tag)
    for href in _HREF_RE.findall(body):
        low = href.lower()
        if low.split("?")[0].endswith(_VIDEO_EXT) and href not in out:
            out.append(href)
        elif "pixeldrain.com/u/" in low:
            pid = href.rstrip("/").split("/")[-1]
            api = "https://pixeldrain.com/api/file/" + pid
            if api not in out:
                out.append(api)
    return out
