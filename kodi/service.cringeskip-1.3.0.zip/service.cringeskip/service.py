"""CringeMDB Skip — Kodi service.

Watches whatever video is playing, identifies the movie (title +
year from the player's info, with a filename-parse fallback),
looks up its flagged scenes on CringeMDB, and automatically seeks
past them — a ClearPlay-style skip for streams, driven by
CringeMDB's community scene data.

Scene times come from other releases, so they can be off by a few
seconds on a given stream; the lead-seconds setting pads the start
of each skip. A range is skipped at most once per playback — if
you seek back into it on purpose, it plays.

v1.1.0 adds two things at Karthi's request: when the movie cannot
be identified from labels, the player item or the filename, the
service asks the user for the movie name once per file; and a
subtitle word filter — when a subtitle file is downloaded for the
playing movie, a filtered copy (listed words masked as ****) is
swapped in via Player.setSubtitles. Embedded subtitles cannot be
reached and are left alone.

v1.2.0 adds a fallback scene source: when CringeMDB yields no
skippable scenes for a movie (no page, a verdict but no scene
times yet, or nothing in the enabled categories), the service
also tries Filmiway, whose pages carry hand-verified skip
timestamps for sex/nudity scenes. CringeMDB stays the primary
source; Filmiway only fills its gaps.

v1.2.1 fixes the ask-for-title prompt never firing for junk
titles: the prompt used to require an EMPTY title, but addons
often hand the player a raw release/topic title — junk, yet
non-empty, so it counted as identified and the lookup just
missed quietly. Now, when a lookup finishes with no match on
either source, the service asks once per file which movie it
really is, and the answer takes precedence over the labels.

v1.2.2 attacks the junk itself: lookups gain a release-title
cleaner (cringemdb.clean_release_title) as an extra attempt —
it extracts the year, drops bracketed tags, and cuts the title
at the first quality/codec/language token ('[TamilDub]
Resident Evil (2026) 720p' and 'Resident Evil Tamil Dubbed
(2026)' both become 'resident evil' + 2026), so most junk
titles now match on CringeMDB/Filmiway without any prompt.
Matching stays strict, so a bad clean can never attach a
wrong movie; the prompt remains as the last resort.

v1.2.3 pauses the video while the ask-for-title prompt is up
(his request): the movie no longer plays on, unprotected,
while he reads and types the real title. The service resumes
only what it paused itself, only if the same file is still
loaded, and leaves a movie he paused himself alone.

v1.2.4 widens the subtitle search: the filter used to scan a
fixed list of known subtitle addons' folders and reported
"no subtitle file found" when a download landed anywhere
else. It now scans Kodi's temp folder plus every addon's
data folder, so a subtitle downloaded by any subtitle addon
is found. (His first test used the stream's built-in
"eng | pgs" track — PGS subtitles are pictures, not text,
so there is no file and nothing to filter; a downloaded
text subtitle is the way to test the filter.)

v1.3.0 makes the skip information viewable on demand (his
request): the service mirrors its state — movie, source,
armed scenes with their times — into a window property,
and a companion script in the same addon (scenes.py, listed
under Program addons, favourite-able) shows that list over
the video whenever he wants it, calling out the next scene.
The arming notification now includes the scene start times
too. (The built-in player Information panel itself can only
show what the source addon attached at press-play time —
the TML/4KHUB addons now attach poster and plot; a service
cannot write into that panel.)
"""
import json
import os
import re
import sys
import threading
import time

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon("service.cringeskip")
# Make sure this addon's own folder is importable — it is not on
# sys.path in every Kodi service context, and a failed import
# would kill the service silently at startup.
sys.path.insert(0, ADDON.getAddonInfo("path"))

import cringemdb
import filmiway
import subfilter
LOG_PREFIX = "[service.cringeskip] "
# Window property the "Skip scenes" companion script reads.
STATE_PROP = "service.cringeskip.state"


def _fmt_clock(seconds):
    """165 -> '2:45'; 5127 -> '1:25:27'."""
    seconds = max(0, int(seconds))
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    if h:
        return "%d:%02d:%02d" % (h, m, s)
    return "%d:%02d" % (m, s)


def log(msg):
    xbmc.log(LOG_PREFIX + msg, xbmc.LOGINFO)


def notify(text):
    try:
        xbmcgui.Dialog().notification(
            "CringeMDB Skip", text, ADDON.getAddonInfo("icon"), 3500, False)
    except Exception:
        pass


def debug_notify(text):
    """Progress announcements while we shake the service down."""
    try:
        if ADDON.getSettingBool("debug"):
            notify(text)
    except Exception:
        pass


def player_item():
    """The playing item's metadata via JSON-RPC (title/year/label)."""
    try:
        res = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1,
            "method": "Player.GetActivePlayers", "params": {}})))
        pid = next((p["playerid"] for p in res.get("result", [])
                    if p.get("type") == "video"), None)
        if pid is None:
            return {}
        res = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "Player.GetItem",
            "params": {"playerid": pid,
                       "properties": ["title", "year", "label"]}})))
        return res.get("result", {}).get("item", {}) or {}
    except Exception:
        return {}


def _active_video_player():
    """The active video player's id, or None."""
    try:
        res = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1,
            "method": "Player.GetActivePlayers", "params": {}})))
        return next((p["playerid"] for p in res.get("result", [])
                     if p.get("type") == "video"), None)
    except Exception:
        return None


def _player_speed(pid):
    """Playback speed (1 = playing, 0 = paused), None if unknown."""
    try:
        res = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "Player.GetProperties",
            "params": {"playerid": pid, "properties": ["speed"]}})))
        return (res.get("result", {}) or {}).get("speed")
    except Exception:
        return None


def _play_pause(pid, play):
    try:
        xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "Player.PlayPause",
            "params": {"playerid": pid, "play": bool(play)}}))
    except Exception:
        pass


def _playing_file_now():
    try:
        return xbmc.Player().getPlayingFile()
    except Exception:
        return None


def seek_to(player, seconds):
    """Absolute seek (seconds). Verifies the JSON-RPC result —
    an RPC error reply is NOT a successful seek — and falls back
    to the player object's own seek. Returns (ok, how)."""
    seconds = max(0, int(round(seconds)))
    try:
        active = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1,
            "method": "Player.GetActivePlayers", "params": {}})))
        players = active.get("result", [])
        pid = next((p["playerid"] for p in players
                    if p.get("type") == "video"),
                   players[0]["playerid"] if players else 1)
        h, rem = divmod(seconds, 3600)
        m, s = divmod(rem, 60)
        resp = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "Player.Seek",
            "params": {"playerid": pid, "value": {
                "hours": h, "minutes": m, "seconds": s,
                "milliseconds": 0}}})))
        if resp.get("result") == "OK" and "error" not in resp:
            return True, "rpc"
        log("seek RPC not OK: %r" % (resp,))
    except Exception as e:
        log("seek RPC failed: %r" % (e,))
    try:
        player.seekTime(float(seconds))
        return True, "seekTime"
    except Exception as e:
        log("seekTime failed: %r" % (e,))
        return False, "none"


def lead_seconds():
    """The lead setting, read defensively (slider storage has
    varied across Kodi versions; never let it kill the cycle)."""
    try:
        return ADDON.getSettingInt("lead_seconds")
    except Exception:
        pass
    try:
        return int(ADDON.getSetting("lead_seconds"))
    except Exception:
        return 2


def _prepare_ranges(scenes, skip_sexual, skip_violence):
    """Filter scenes by the category settings and merge
    overlapping / near-identical ranges (a source sometimes
    lists a scene twice)."""
    chosen = []
    for s in scenes:
        if cringemdb.is_sexual(s["category"]) and not skip_sexual:
            continue
        if cringemdb.is_violence(s["category"]) and not skip_violence:
            continue
        chosen.append(s)
    ranges = []
    for s in sorted(chosen, key=lambda x: x["start"]):
        if ranges and s["start"] <= ranges[-1]["end"] + 2:
            ranges[-1]["end"] = max(ranges[-1]["end"], s["end"])
        else:
            ranges.append({"start": s["start"], "end": s["end"],
                           "category": s["category"], "done": False})
    return ranges


def parse_user_title(text):
    """'Zodiac 2007' / 'Zodiac (2007)' -> ('Zodiac', 2007);
    'Zodiac' -> ('Zodiac', None); empty -> None."""
    text = (text or "").strip()
    if not text:
        return None
    year = None
    m = re.search(r"\(((?:19|20)\d{2})\)", text)
    if m:
        year = int(m.group(1))
        text = (text[:m.start()] + text[m.end():]).strip()
    else:
        m = re.search(r"\b((?:19|20)\d{2})\b\s*$", text)
        if m:
            year = int(m.group(1))
            text = text[:m.start()].strip()
    title = text.strip(" -–:").strip()
    if not title:
        return None
    return title, year


def current_subtitle_info():
    """(subtitle_enabled, current_subtitle_name) via JSON-RPC;
    (None, '') when unknown."""
    try:
        res = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1,
            "method": "Player.GetActivePlayers", "params": {}})))
        pid = next((p["playerid"] for p in res.get("result", [])
                    if p.get("type") == "video"), None)
        if pid is None:
            return None, ""
        res = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "Player.GetProperties",
            "params": {"playerid": pid,
                       "properties": ["subtitleenabled",
                                      "currentsubtitle"]}})))
        props = res.get("result", {}) or {}
        cur = props.get("currentsubtitle") or {}
        return props.get("subtitleenabled"), cur.get("name", "") or ""
    except Exception:
        return None, ""


class SkipService:
    def __init__(self):
        self.key = None          # (file, title, year) being tracked
        self.ranges = []         # prepared skip ranges for self.key
        self.lookup_state = "idle"   # idle | working | done
        self.lookup_missed = False   # done, and no source knew the title
        self.lookup_source = None    # CringeMDB | Filmiway | None
        self.disp_title = None       # title as shown to the user
        self.disp_year = None
        self._state_sig = None       # last published state JSON
        self._unidentified_file = None
        self._pending_verify = None  # (range, attempts) after a seek
        self._lock = threading.Lock()
        # Ask-for-title state (when identification fails).
        self._unidentified_since = None  # (file, time.time())
        self._prompted_files = set()
        self._user_titles = {}   # playing_file -> (title, year)
        # Subtitle filter state.
        self._sub_playing_file = None
        self._sub_started = 0.0
        self._sub_last_check = 0.0
        self._sub_seen = None    # (path, mtime, size) candidate
        self._sub_applied = None  # (path, mtime) already swapped in
        self._sub_nofile_notified = False

    # ------------------------------------------------------------ lookup
    def _publish_state(self, status, scenes=None):
        """Mirror the skip state into a window property so the
        companion 'Skip scenes' script (scenes.py) can show it
        on demand — a background service has no UI of its own.
        Signature-gated: identical states are not rewritten."""
        payload = {"status": status, "title": self.disp_title,
                   "year": self.disp_year,
                   "source": self.lookup_source,
                   "scenes": scenes or []}
        sig = json.dumps(payload, sort_keys=True)
        if sig == self._state_sig:
            return
        self._state_sig = sig
        try:
            xbmcgui.Window(10000).setProperty(STATE_PROP, sig)
        except Exception:
            pass

    def _clear_state(self):
        self._state_sig = None
        self.disp_title = None
        self.disp_year = None
        self.lookup_source = None
        try:
            xbmcgui.Window(10000).setProperty(STATE_PROP, "")
        except Exception:
            pass

    def _start_lookup(self, title, year):
        self.lookup_state = "working"
        self.lookup_missed = False
        self.lookup_source = None
        self.disp_title = title
        self.disp_year = year
        self._publish_state("working")

        def work():
            guide = None
            error = None
            try:
                guide = cringemdb.find_guide(title, year)
            except Exception as e:
                error = e
                log("lookup failed for %r (%r): %r" % (title, year, e))
            try:
                skip_sexual = ADDON.getSettingBool("skip_sexual")
                skip_violence = ADDON.getSettingBool("skip_violence")
            except Exception:
                skip_sexual, skip_violence = True, False
            ranges = []
            source = None
            if guide and guide.get("not_safe"):
                ranges = _prepare_ranges(guide["scenes"],
                                         skip_sexual, skip_violence)
                if ranges:
                    source = "CringeMDB"
                log("guide for %r (%r): %d scenes -> %d skip ranges"
                    % (title, year, len(guide["scenes"]), len(ranges)))
            elif guide:
                log("guide for %r (%r): SAFE, nothing to skip" % (title, year))
            else:
                log("no CringeMDB guide for %r (%r)" % (title, year))
            fw = None
            if not ranges and error is None:
                # CringeMDB gave us nothing skippable — try the
                # Filmiway fallback before giving up (v1.2.0).
                try:
                    fw = filmiway.find_guide(title, year)
                except Exception as e:
                    log("filmiway lookup failed for %r (%r): %r"
                        % (title, year, e))
                if fw and fw.get("scenes"):
                    ranges = _prepare_ranges(fw["scenes"],
                                             skip_sexual, skip_violence)
                    if ranges:
                        source = "Filmiway"
                    log("filmiway guide for %r (%r): %d scenes -> "
                        "%d skip ranges"
                        % (title, year, len(fw["scenes"]), len(ranges)))
                elif fw:
                    log("filmiway guide for %r (%r): no timed scenes"
                        % (title, year))
                else:
                    log("no Filmiway guide for %r (%r)" % (title, year))
            with self._lock:
                self.ranges = ranges
                self.lookup_source = source
                # A clean miss on BOTH sources means the title we
                # were handed matched nothing anywhere — probably
                # junk. cycle() turns that into a title prompt.
                self.lookup_missed = (guide is None and fw is None
                                      and error is None)
                self.lookup_state = "done"
            if error is not None:
                debug_notify("Lookup failed: %s" % type(error).__name__)
            elif ranges:
                starts = ", ".join(_fmt_clock(r["start"])
                                   for r in ranges[:6])
                if len(ranges) > 6:
                    starts += " +%d more" % (len(ranges) - 6)
                if source == "Filmiway":
                    debug_notify("%s: %d scene(s) will be skipped "
                                 "(Filmiway): %s"
                                 % (title, len(ranges), starts))
                else:
                    debug_notify("%s: %d scene(s) will be skipped: %s"
                                 % (title, len(ranges), starts))
            elif guide is None:
                debug_notify("No scene guide for %s" % title)
            elif not guide.get("not_safe"):
                debug_notify("%s: SAFE on CringeMDB" % title)
            else:
                try:
                    states = "sex=%s violence=%s" % (
                        ADDON.getSettingBool("skip_sexual"),
                        ADDON.getSettingBool("skip_violence"))
                except Exception:
                    states = "settings unreadable"
                debug_notify("%s: guide found, no scenes armed (%s)"
                             % (title, states))

        threading.Thread(target=work, daemon=True).start()

    # ------------------------------------------------- ask for a title
    def _ask_title(self, heading=None):
        """Prompt the user for the movie name when nothing else
        could identify the playing video. Returns (title, year)
        or None. Blocking — called from the service loop, at most
        once per file."""
        if not heading:
            heading = ("CringeMDB Skip: which movie is this? "
                       "(year helps, e.g. Zodiac 2007)")
        # Pause while the user answers (his request, 2026-11-03):
        # a prompt over a playing movie lets unprotected scenes
        # roll by while he reads and types. Only pause a movie
        # that is actually playing, and afterwards resume only
        # what this prompt paused — never unpause something the
        # user paused himself, and never resume into a different
        # file if playback moved on while the dialog was up.
        pid = _active_video_player()
        file_at_pause = _playing_file_now()
        paused_here = False
        if pid is not None and _player_speed(pid):
            _play_pause(pid, False)
            paused_here = True
        text = ""
        try:
            dlg = xbmcgui.Dialog()
            try:
                text = dlg.input(
                    heading,
                    type=xbmcgui.INPUT_ALPHANUM, autoclose=90000)
            except TypeError:
                text = dlg.input(
                    heading,
                    type=xbmcgui.INPUT_ALPHANUM)
        finally:
            if (paused_here and _active_video_player() == pid
                    and _playing_file_now() == file_at_pause
                    and not _player_speed(pid)):
                _play_pause(pid, True)
        parsed = parse_user_title(text)
        if parsed:
            log("user identified the movie as %r (%r)" % parsed)
            debug_notify("Looking up %s — thanks" % parsed[0])
        return parsed

    # ------------------------------------------------- subtitle filter
    SUB_EXTS = (".srt", ".ass", ".ssa", ".vtt")

    def _subtitle_dirs(self):
        dirs = []
        try:
            dirs.append(xbmcvfs.translatePath("special://temp/"))
        except Exception:
            pass
        try:
            # Every addon's data folder, not just the subtitle
            # addons we happen to know by name: any subtitle
            # addon may keep its downloads under its own folder
            # here, and a fixed list missed at least one tester's
            # addon entirely ("no subtitle file found" even
            # though a subtitle had just been downloaded).
            dirs.append(xbmcvfs.translatePath(
                "special://profile/addon_data/"))
        except Exception:
            pass
        return [d for d in dirs if d and os.path.isdir(d)]

    def _find_subtitle(self, playing_file):
        """The subtitle file belonging to this playback, as
        (path, mtime, size), or None. Preference order: the file
        Kodi says is the current subtitle (by name), a sidecar
        file next to a local video, then the newest subtitle
        downloaded around the start of this playback."""
        candidates = []
        for base in self._subtitle_dirs():
            for root, dirnames, filenames in os.walk(base):
                # Never scan our own filtered-output folder, and
                # keep the walk shallow.
                dirnames[:] = [d for d in dirnames
                               if "service.cringeskip" not in
                               os.path.join(root, d)]
                if root[len(base):].count(os.sep) >= 3:
                    dirnames[:] = []
                for fn in filenames:
                    if os.path.splitext(fn)[1].lower() in self.SUB_EXTS:
                        path = os.path.join(root, fn)
                        try:
                            st = os.stat(path)
                        except OSError:
                            continue
                        candidates.append(
                            (path, st.st_mtime, st.st_size))
        if not candidates:
            return None
        _, cur_name = current_subtitle_info()
        if cur_name:
            base_name = os.path.basename(cur_name)
            for cand in candidates:
                if os.path.basename(cand[0]) == base_name:
                    return cand
        # Sidecar next to a local video file (same stem).
        if playing_file and "://" not in playing_file:
            stem = os.path.splitext(playing_file)[0].lower()
            for cand in candidates:
                if os.path.splitext(cand[0])[0].lower() == stem:
                    return cand
            for ext in self.SUB_EXTS:
                path = os.path.splitext(playing_file)[0] + ext
                if os.path.isfile(path):
                    try:
                        st = os.stat(path)
                        return path, st.st_mtime, st.st_size
                    except OSError:
                        pass
        recent = [c for c in candidates
                  if c[1] >= self._sub_started - 90]
        if recent:
            return max(recent, key=lambda c: c[1])
        return None

    def _apply_subtitle(self, player, cand):
        path, mtime, _ = cand
        enabled, _ = current_subtitle_info()
        if enabled is False:
            # Subtitles are off; don't fight the user.
            self._sub_applied = (path, mtime)
            log("subtitle file found but subtitles are off: %s" % path)
            return
        try:
            with open(path, "rb") as f:
                data = f.read()
        except OSError as e:
            log("subtitle read failed: %r" % (e,))
            return
        words = subfilter.parse_words(ADDON.getSetting("sub_words"))
        text = subfilter.decode_subtitle(data)
        ext = os.path.splitext(path)[1].lower()
        new_text, count = subfilter.filter_subtitle(text, ext, words)
        self._sub_applied = (path, mtime)
        if count == 0:
            log("subtitle checked, nothing to hide: %s" % path)
            debug_notify("Subtitle checked: nothing to hide")
            return
        out_dir = xbmcvfs.translatePath(
            "special://profile/addon_data/service.cringeskip/filtered/")
        try:
            if not os.path.isdir(out_dir):
                os.makedirs(out_dir)
            stem = os.path.splitext(os.path.basename(path))[0]
            out_path = os.path.join(out_dir, stem + ".filtered" + ext)
            with open(out_path, "w", encoding="utf-8") as f:
                f.write(new_text)
        except OSError as e:
            log("filtered subtitle write failed: %r" % (e,))
            return
        try:
            player.setSubtitles(out_path)
        except Exception as e:
            log("setSubtitles failed: %r" % (e,))
            return
        log("subtitle filter applied: %d word(s) hidden in %s"
            % (count, path))
        debug_notify("Subtitle filter: hid %d word(s)" % count)

    def _subtitle_cycle(self, player, playing_file):
        try:
            if not ADDON.getSettingBool("filter_subs"):
                return
        except Exception:
            return
        now = time.time()
        if playing_file != self._sub_playing_file:
            self._sub_playing_file = playing_file
            self._sub_started = now
            self._sub_seen = None
            self._sub_applied = None
            self._sub_nofile_notified = False
        if now - self._sub_last_check < 4:
            return
        self._sub_last_check = now
        cand = self._find_subtitle(playing_file)
        if cand is None:
            if (now - self._sub_started > 45
                    and not self._sub_nofile_notified):
                self._sub_nofile_notified = True
                debug_notify("Subtitle filter: no subtitle file found")
            return
        sig = (cand[0], cand[1], cand[2])
        if self._sub_seen != sig:
            # First sighting: wait for the next check to be sure
            # the download has finished writing.
            self._sub_seen = sig
            return
        if self._sub_applied == (cand[0], cand[1]):
            return
        self._apply_subtitle(player, cand)

    # ------------------------------------------------------------ cycle
    def cycle(self, player):
        if not ADDON.getSettingBool("enabled"):
            return
        if not player.isPlayingVideo():
            if self.key is not None:
                self.key = None
                self.ranges = []
                self.lookup_state = "idle"
                self._clear_state()
            self._sub_playing_file = None
            return

        try:
            playing_file = player.getPlayingFile()
        except Exception:
            playing_file = ""

        # The subtitle filter needs no identification — run it on
        # its own slower cadence before anything can return early.
        try:
            self._subtitle_cycle(player, playing_file)
        except Exception as e:
            log("subtitle cycle error: %r" % (e,))

        title = (xbmc.getInfoLabel("VideoPlayer.Title") or "").strip()
        year_raw = (xbmc.getInfoLabel("VideoPlayer.Year") or "").strip()
        try:
            year = int(year_raw) if year_raw else None
        except ValueError:
            year = None

        if not title or year is None:
            item = player_item()
            if not title:
                title = (item.get("title") or item.get("label")
                         or "").strip()
            if year is None and item.get("year"):
                try:
                    year = int(item["year"])
                except Exception:
                    pass
        if playing_file in self._user_titles:
            # The user's own answer beats whatever the player
            # labels carry — the labels are why we had to ask.
            title, year = self._user_titles[playing_file]
        if not title:
            parsed = cringemdb.parse_filename(playing_file)
            if parsed:
                title, year = parsed
        if not title:
            # Identification failed. Give the labels a few seconds
            # to arrive, then — once per file — ask the user which
            # movie this is (his request, 2026-11-03).
            if self._unidentified_file != playing_file:
                self._unidentified_file = playing_file
                self._unidentified_since = (playing_file, time.time())
                debug_notify("Could not identify this movie")
            try:
                ask = ADDON.getSettingBool("ask_title")
            except Exception:
                ask = False
            since = self._unidentified_since
            if (ask and since and since[0] == playing_file
                    and time.time() - since[1] >= 6
                    and playing_file not in self._prompted_files):
                self._prompted_files.add(playing_file)
                got = self._ask_title()
                if got:
                    self._user_titles[playing_file] = got
                    title, year = got
            if not title:
                return

        key = (playing_file, cringemdb.clean_title(title), year)
        if key != self.key:
            self.key = key
            self.ranges = []
            debug_notify("Watching: %s (%s)"
                         % (title, year if year else "?"))
            self._start_lookup(title, year)
            return
        if (self.lookup_state == "done" and self.lookup_missed
                and playing_file not in self._user_titles):
            # The labels handed us a title, but neither source
            # knows anything under that name — it is probably a
            # junk release/topic title. Ask once per file which
            # movie this really is (v1.2.1; in v1.2.0 this case
            # never prompted, because a junk title still counted
            # as "identified").
            try:
                ask = ADDON.getSettingBool("ask_title")
            except Exception:
                ask = False
            if ask and playing_file not in self._prompted_files:
                self._prompted_files.add(playing_file)
                got = self._ask_title(
                    "CringeMDB Skip: couldn't find '%s' — which "
                    "movie is this? (year helps)" % title[:40])
                if got:
                    self._user_titles[playing_file] = got
            return
        if self.lookup_state == "done":
            # Keep the on-demand scene view current (the done
            # flags flip as scenes get skipped).
            if self.ranges:
                self._publish_state("armed", [
                    {"start": r["start"], "end": r["end"],
                     "category": r["category"],
                     "done": bool(r["done"])}
                    for r in self.ranges])
            elif self.lookup_missed:
                self._publish_state("missed")
            else:
                self._publish_state("none")
        if self.lookup_state != "done" or not self.ranges:
            return

        try:
            t = player.getTime()
        except Exception:
            return
        # A seek that was accepted but didn't take (seen with
        # some HLS streams): if we are still inside the scene a
        # few seconds later, try the other seek method, twice.
        if self._pending_verify is not None:
            r, attempts = self._pending_verify
            if t >= r["end"]:
                self._pending_verify = None
            elif attempts < 2:
                ok, how = seek_to(player, r["end"] + 1)
                log("verify: still in scene at t=%.0f, retry %d -> %s"
                    % (t, attempts + 1, how))
                self._pending_verify = (r, attempts + 1)
            else:
                debug_notify("Seek is not taking on this stream")
                self._pending_verify = None
            return
        lead = lead_seconds()
        for r in self.ranges:
            if r["done"]:
                continue
            if r["start"] - lead <= t < r["end"]:
                r["done"] = True
                debug_notify("Skipping now: %s scene" % r["category"])
                ok, how = seek_to(player, r["end"] + 1)
                if ok:
                    log("skipped %s scene %d-%ds at t=%.0f via %s"
                        % (r["category"], r["start"], r["end"], t, how))
                    if ADDON.getSettingBool("notify"):
                        notify("Skipped: %s scene" % r["category"])
                    self._pending_verify = (r, 0)
                else:
                    debug_notify("Seek failed for %s scene"
                                 % r["category"])
                break


def main():
    monitor = xbmc.Monitor()
    player = xbmc.Player()
    service = SkipService()
    log("service started")
    while not monitor.abortRequested():
        try:
            service.cycle(player)
        except Exception as e:
            log("cycle error: %r" % (e,))
        if monitor.waitForAbort(0.5):
            break
    log("service stopped")


if __name__ == "__main__":
    main()
