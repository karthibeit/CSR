"""CringeMDB Skip — Scenes viewer (standalone script addon).

Lists the scenes the CringeMDB Skip service will skip for the
movie now playing. It lives in its own tiny addon because the
service addon itself does not show under Program add-ons on
every Kodi build; a script-only addon always does.

The service publishes its state (movie, source, armed scenes)
in a window property; this script simply reads and shows it,
over the video, without stopping playback.
"""
import json

import xbmc
import xbmcgui

PROP = "service.cringeskip.state"
HEADING = "CringeMDB Skip — scenes"


def _fmt_clock(seconds):
    """165 -> '2:45'; 5127 -> '1:25:27'."""
    seconds = max(0, int(seconds))
    h, rem = divmod(seconds, 3600)
    m, s = divmod(rem, 60)
    if h:
        return "%d:%02d:%02d" % (h, m, s)
    return "%d:%02d" % (m, s)


def _load_state():
    try:
        raw = xbmcgui.Window(10000).getProperty(PROP)
    except Exception:
        raw = ""
    if not raw:
        return None
    try:
        return json.loads(raw)
    except Exception:
        return None


def _show(heading, body):
    dlg = xbmcgui.Dialog()
    try:
        dlg.textviewer(heading, body)
    except Exception:
        dlg.ok(heading, body)


def main():
    state = _load_state()
    if not state:
        _show(HEADING,
              "No skip information yet.\n\n"
              "Play a movie and give the lookup a few seconds, "
              "then open this again.")
        return
    title = state.get("title") or "This movie"
    year = state.get("year")
    heading = "%s (%s)" % (title, year) if year else title
    status = state.get("status")
    if status == "working":
        _show(heading,
              "Still looking this movie up — try again in a "
              "few seconds.")
        return
    if status == "missed":
        _show(heading,
              "No scene guide was found for this title on "
              "CringeMDB or Filmiway.\n\n"
              "If the name above is not the real movie, the "
              "service may have asked you for the real name "
              "when playback started.")
        return
    scenes = state.get("scenes") or []
    if status == "none" or not scenes:
        _show(heading,
              "No scenes will be skipped for this movie.\n\n"
              "Either it is marked safe, or its flagged scenes "
              "are outside the categories enabled in the "
              "service settings.")
        return
    now = None
    try:
        now = xbmc.Player().getTime()
    except Exception:
        now = None
    lines = []
    if state.get("source"):
        lines.append("Source: %s" % state["source"])
        lines.append("")
    next_marked = False
    for sc in scenes:
        line = "%s – %s · %s" % (_fmt_clock(sc.get("start", 0)),
                                 _fmt_clock(sc.get("end", 0)),
                                 sc.get("category", ""))
        if sc.get("done"):
            line += "  (skipped)"
        elif now is not None and sc["start"] <= now < sc["end"]:
            line += "  (on screen now)"
        elif (now is not None and not next_marked
                and sc["end"] > now):
            line += "  ◀ next (in %s)" % _fmt_clock(sc["start"] - now)
            next_marked = True
        lines.append(line)
    _show(heading, "\n".join(lines))


if __name__ == "__main__":
    main()
