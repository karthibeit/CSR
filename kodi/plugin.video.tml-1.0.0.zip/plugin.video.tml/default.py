"""TML for Kodi — 1TamilMV sections, search and playback.

Port of the CloudStream TML plugin to a Kodi video addon. Direct links are
resolved through the shortener chain and played by Kodi itself; magnet and
.torrent links are handed to the Elementum addon when it is installed.
"""
import json
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
PLUGIN_URL = sys.argv[0]

sys.path.append(ADDON.getAddonInfo("path") + "resources/lib")
import tmlsite  # noqa: E402


def build_url(**params):
    return PLUGIN_URL + "?" + urllib.parse.urlencode(params)


def notify(msg):
    xbmcgui.Dialog().notification("TML", msg, xbmcgui.NOTIFICATION_INFO, 4000)


def add_dir(label, url, is_folder=True, art=None, info=None, playable=False):
    item = xbmcgui.ListItem(label=label)
    if art:
        item.setArt(art)
    if info:
        item.setInfo("video", info)
    if playable:
        item.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=is_folder)


def root():
    add_dir("Search", build_url(mode="search_keyboard"))
    for url, name in tmlsite.SECTIONS:
        if "#top-releases" in url:
            mode = "banger"
            extra = {"key": "TOP RELEASES", "url": url}
        elif "#recently-added" in url:
            mode = "banger"
            extra = {"key": "RECENTLY ADDED", "url": url}
        else:
            mode = "section"
            extra = {"url": url, "page": 1}
        extra["mode"] = mode
        add_dir(name, build_url(**extra))
    xbmcplugin.endOfDirectory(HANDLE)


def list_topics(items, next_url=None):
    for it in items:
        add_dir(it["title"], build_url(mode="topic", url=it["url"]))
    if next_url:
        add_dir("Next page >>", next_url)
    xbmcplugin.endOfDirectory(HANDLE)


def section(url, page):
    page_url = url
    if page > 1:
        page_url = url + ("&page=%d" if "?" in url else "?page=%d") % page
    root_el = tmlsite.parse(tmlsite.fetch(page_url))
    items = tmlsite.extract_threads(root_el, page_url)
    next_url = None
    if len(items) >= 15:
        next_url = build_url(mode="section", url=url, page=page + 1)
    list_topics(items, next_url)


def banger(url, key):
    base = url.split("#")[0]
    root_el = tmlsite.parse(tmlsite.fetch(base))
    items = tmlsite.extract_banger(root_el, base, key, limit=50)
    if not items:
        items = tmlsite.extract_threads(root_el, base)
    list_topics(items)


def search_keyboard():
    kb = xbmc.Keyboard("", "Search TML")
    kb.doModal()
    if not kb.isConfirmed():
        xbmcplugin.endOfDirectory(HANDLE)
        return
    query = kb.getText().strip()
    if not query:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    list_topics(tmlsite.search(query))


def _play_info(title, rich, post_text):
    info = {"title": title, "plot": (rich or {}).get("plot") or post_text}
    if rich:
        if rich.get("rating"):
            info["rating"] = rich["rating"]
        if rich.get("duration"):
            info["duration"] = rich["duration"] * 60
        if rich.get("genres"):
            info["genre"] = " / ".join(rich["genres"])
        if rich.get("cast"):
            info["cast"] = rich["cast"]
        if rich.get("year"):
            info["year"] = rich["year"]
    return info


def _link_item(link, title, art, info):
    label = link["label"]
    if link["kind"] == "magnet":
        label = "[MAGNET] " + label
    elif link["kind"] == "torrent":
        label = "[TORRENT] " + label
    payload = json.dumps(link)
    add_dir(label, build_url(mode="play", data=payload, title=title),
            is_folder=False, art=art, info=info, playable=True)


def topic(url):
    html_text = tmlsite.fetch(url)
    root_el = tmlsite.parse(html_text)
    title = tmlsite.clean_thread_title(tmlsite.og_title(root_el))
    post = tmlsite.first_post(root_el)
    poster = tmlsite.og_image(root_el, url) \
        or tmlsite.poster_from_post(post, url)
    links = tmlsite.collect_links(post, url)

    series = tmlsite.is_series(title)
    rich = tmlsite.fetch_rich(title, series=series)
    if rich and rich.get("poster"):
        poster = rich["poster"]
    art = {}
    if poster:
        art = {"poster": poster, "thumb": poster, "fanart":
               (rich or {}).get("background") or poster}
    info = _play_info(title, rich, post.text().strip()[:2000])

    if series:
        batches = tmlsite.group_episode_batches(links, title)
        if batches:
            season = tmlsite.season_of(title)
            for (a, b) in sorted(batches.keys()):
                for n in range(a, b + 1):
                    payload = json.dumps(batches[(a, b)])
                    add_dir("S%02d E%02d — Episode %d" % (season, n, n),
                            build_url(mode="episode", data=payload,
                                      title=title, ep=n),
                            is_folder=True, art=art, info=info)
            xbmcplugin.endOfDirectory(HANDLE)
            return
    for link in links:
        _link_item(link, title, art, info)
    if rich and rich.get("trailer"):
        add_dir("Trailer", build_url(mode="trailer", url=rich["trailer"]),
                is_folder=False, art=art, info=info, playable=True)
    xbmcplugin.endOfDirectory(HANDLE)


def episode(data_json, title, ep):
    links = json.loads(data_json)
    for link in links:
        _link_item(link, "%s — Episode %s" % (title, ep), None, None)
    xbmcplugin.endOfDirectory(HANDLE)


def play(data_json, title):
    link = json.loads(data_json)
    url, kind = link["url"], link["kind"]
    if kind == "direct_button":
        notify("Resolving direct link...")
        final = tmlsite.resolve_short_link(url)
        if not final:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            xbmcgui.Dialog().ok("TML", "Could not resolve the direct link.")
            return
        url = final
    elif kind in ("magnet", "torrent"):
        if xbmc.getCondVisibility(
                "System.HasAddon(plugin.video.elementum)"):
            url = ("plugin://plugin.video.elementum/play?uri="
                   + urllib.parse.quote(url, safe=""))
        else:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            xbmcgui.Dialog().ok(
                "TML",
                "This is a torrent/magnet link. Install the Elementum "
                "addon in Kodi to play it, or pick a DIRECT link instead.")
            return
    item = xbmcgui.ListItem(path=url)
    item.setInfo("video", {"title": title})
    xbmcplugin.setResolvedUrl(HANDLE, True, item)


def trailer(url):
    item = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(HANDLE, True, item)


def main():
    params = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip("?")))
    mode = params.get("mode", "root")
    try:
        if mode == "root":
            root()
        elif mode == "section":
            section(params["url"], int(params.get("page", "1")))
        elif mode == "banger":
            banger(params["url"], params["key"])
        elif mode == "search_keyboard":
            search_keyboard()
        elif mode == "topic":
            topic(params["url"])
        elif mode == "episode":
            episode(params["data"], params.get("title", ""),
                    params.get("ep", ""))
        elif mode == "play":
            play(params["data"], params.get("title", ""))
        elif mode == "trailer":
            trailer(params["url"])
        else:
            root()
    except Exception as e:
        xbmc.log("TML addon error: %r" % (e,), xbmc.LOGERROR)
        xbmcgui.Dialog().ok("TML", "Something went wrong:\n%s" % (e,))


if __name__ == "__main__":
    main()
