"""OLA for Kodi — OlaMovies catalogue, downloads and playback.

Browse v6.olamovies.mov (latest posts, categories, search), open a
movie or series page's download releases, and play the file the
shortener chain leads to. Downloads are hosted by third parties
(usually Google Drive); the addon resolves the chain at play time.
Play items carry the real title and year so companion services
(CringeMDB Skip) can identify what is playing.
"""
import hashlib
import json
import re
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
PLUGIN_URL = sys.argv[0]

sys.path.append(ADDON.getAddonInfo("path") + "resources/lib")
import olasite  # noqa: E402


def build_url(**params):
    return PLUGIN_URL + "?" + urllib.parse.urlencode(params)


# Directory listings and the play action run as separate
# invocations, so the art/info a detail page gathered are stashed in
# window properties keyed by payload and title; play() picks them up
# so the player's Information panel shows poster and plot instead of
# "Not available".
STASH_PREFIX = "ola.item."


def _stash_key(text):
    return re.sub(r"[^a-z0-9]+", "_",
                  (text or "").lower()).strip("_")[:80]


def _payload_key(data):
    return "p." + hashlib.md5(
        (data or "").encode("utf-8", "replace")).hexdigest()[:16]


def _stash_put(key, art, info):
    if not key or (not art and not info):
        return
    try:
        xbmcgui.Window(10000).setProperty(
            STASH_PREFIX + key,
            json.dumps({"art": art or {}, "info": info or {}}))
    except Exception:
        pass


def _stash_get(key):
    if not key:
        return None
    try:
        raw = xbmcgui.Window(10000).getProperty(STASH_PREFIX + key)
        if raw:
            return json.loads(raw)
    except Exception:
        pass
    return None


def notify(msg):
    xbmcgui.Dialog().notification(
        "OLA", msg, xbmcgui.NOTIFICATION_INFO, 4000)


def add_dir(label, url, is_folder=True, art=None, info=None,
            playable=False):
    item = xbmcgui.ListItem(label=label)
    if art:
        item.setArt(art)
    if info:
        item.setInfo("video", info)
    if playable:
        item.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=is_folder)


def root():
    add_dir("Latest", build_url(mode="list", kind="home", page=1))
    add_dir("Movies", build_url(mode="list", kind="cat", slug="movies",
                                page=1))
    add_dir("TV Series", build_url(mode="list", kind="cat",
                                   slug="tv-series", page=1))
    add_dir("South Indian", build_url(mode="list", kind="cat",
                                      slug="south-indian", page=1))
    add_dir("Collections", build_url(mode="list", kind="tag",
                                     slug="collection", page=1))
    add_dir("Categories", build_url(mode="cats"))
    add_dir("Search", build_url(mode="search_keyboard"))
    xbmcplugin.endOfDirectory(HANDLE)


def cats():
    for slug, name in olasite.CATEGORIES:
        add_dir(name, build_url(mode="list", kind="cat", slug=slug,
                                page=1))
    xbmcplugin.endOfDirectory(HANDLE)


def listing(kind, slug, page, query=None):
    url = olasite.list_url(kind, slug=slug, page=page, query=query)
    items = olasite.parse_cards(olasite.fetch(url))
    for it in items:
        title = olasite.clean_title(it["title"])
        art = None
        if it["poster"]:
            art = {"poster": it["poster"], "thumb": it["poster"],
                   "fanart": it["poster"]}
        info = {"title": title}
        year = olasite.year_of(it["title"])
        if year:
            info["year"] = year
        if it["kind"] == "tv-series":
            info["mediatype"] = "tvshow"
        add_dir(title, build_url(mode="detail", url=it["url"]),
                art=art, info=info)
    if len(items) >= 10:
        params = {"mode": "list", "kind": kind, "page": page + 1}
        if slug:
            params["slug"] = slug
        if query:
            params["query"] = query
        add_dir("Next page >>", build_url(**params))
    xbmcplugin.endOfDirectory(HANDLE)


def search_keyboard():
    kb = xbmc.Keyboard("", "Search OLA")
    kb.doModal()
    if not kb.isConfirmed():
        xbmcplugin.endOfDirectory(HANDLE)
        return
    query = kb.getText().strip()
    if not query:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    listing("search", None, 1, query=query)


def _file_label(item, show_context=True):
    parts = []
    if show_context and item.get("context"):
        parts.append(item["context"])
    label = item.get("label") or ""
    if item.get("episode") and "episode" not in label.lower():
        parts.append("Episode %s" % item["episode"])
    if label:
        parts.append(label)
    elif item.get("filesize"):
        parts.append(item["filesize"])
    if item.get("filesize") and item["filesize"] not in label:
        parts.append(item["filesize"])
    text = " · ".join(p for p in parts if p)
    if item.get("broken"):
        text = "[LINK DOWN] " + text
    return text or (item.get("filename") or "Download")


def _play_item(item, title, year, art, info):
    payload = json.dumps({"url": item["url"],
                          "filename": item.get("filename") or ""})
    _stash_put(_payload_key(payload), art, info)
    _stash_put("t." + _stash_key(title), art, info)
    add_dir(_file_label(item), build_url(mode="play", data=payload,
                                         title=title,
                                         year=year or ""),
            is_folder=False, art=art, info=info, playable=True)


def _detail_art_info(detail):
    art = {}
    if detail["poster"]:
        art = {"poster": detail["poster"], "thumb": detail["poster"],
               "fanart": detail["poster"]}
    info = {"title": detail["title"]}
    if detail["plot"]:
        info["plot"] = detail["plot"][:2000]
    if detail["year"]:
        info["year"] = detail["year"]
    return art, info


def detail(url):
    d = olasite.parse_detail(olasite.fetch(url))
    art, info = _detail_art_info(d)
    _stash_put("t." + _stash_key(d["title"]), art, info)
    if d["is_series"]:
        for idx, season in enumerate(d["seasons"]):
            add_dir("%s (%d items)" % (season["label"],
                                       len(season["items"])),
                    build_url(mode="season", url=url, idx=idx),
                    art=art, info=info)
    else:
        for item in d["files"]:
            _play_item(item, d["title"], d["year"], art, info)
        if not d["files"]:
            xbmcgui.Dialog().ok(
                "OLA", "No download links were found on this page.")
    xbmcplugin.endOfDirectory(HANDLE)


def season(url, idx):
    d = olasite.parse_detail(olasite.fetch(url))
    art, info = _detail_art_info(d)
    try:
        sec = d["seasons"][idx]
    except (IndexError, KeyError):
        xbmcplugin.endOfDirectory(HANDLE)
        return
    for item in sec["items"]:
        _play_item(item, d["title"], d["year"], art, info)
    if not sec["items"]:
        xbmcgui.Dialog().ok("OLA", "No links in this season yet.")
    xbmcplugin.endOfDirectory(HANDLE)


def _fail(msg):
    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    xbmcgui.Dialog().ok("OLA", msg)


def play(data_json, title, year=None):
    link = json.loads(data_json)
    notify("Resolving link...")
    try:
        kind, value = olasite.resolve_link(link["url"])
    except olasite.ResolveError as e:
        _fail(str(e))
        return
    if kind == "choices":
        labels = [urllib.parse.urlparse(u).netloc + " — " +
                  urllib.parse.unquote(
                      urllib.parse.urlparse(u).path.rsplit("/", 1)[-1])
                  [:60] for u in value]
        dlg = xbmcgui.Dialog()
        pick = dlg.select("Pick a source", labels)
        if pick < 0:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        value = value[pick]
        if value.startswith("DRIVE:"):
            value = olasite.drive_download_url(value[6:])
    item = xbmcgui.ListItem(path=value)
    info = {"title": title}
    stash = _stash_get(_payload_key(data_json)) \
        or _stash_get("t." + _stash_key(title))
    art = None
    if stash:
        art = stash.get("art") or None
        for k, v in (stash.get("info") or {}).items():
            if k != "title" and v:
                info[k] = v
    if year:
        try:
            info["year"] = int(year)
        except (TypeError, ValueError):
            pass
    elif info.get("year") is None:
        m = re.search(r"(19\d{2}|20\d{2})", title or "")
        if m:
            info["year"] = int(m.group(1))
    if art:
        item.setArt(art)
    item.setInfo("video", info)
    xbmcplugin.setResolvedUrl(HANDLE, True, item)


def main():
    params = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip("?")))
    mode = params.get("mode", "root")
    try:
        if mode == "root":
            root()
        elif mode == "cats":
            cats()
        elif mode == "list":
            listing(params.get("kind", "home"), params.get("slug"),
                    int(params.get("page", "1")),
                    query=params.get("query"))
        elif mode == "search_keyboard":
            search_keyboard()
        elif mode == "detail":
            detail(params["url"])
        elif mode == "season":
            season(params["url"], int(params.get("idx", "0")))
        elif mode == "play":
            play(params["data"], params.get("title", ""),
                 params.get("year"))
        else:
            root()
    except Exception as e:
        xbmc.log("OLA addon error: %r" % (e,), xbmc.LOGERROR)
        xbmcgui.Dialog().ok("OLA", "Something went wrong:\n%s" % (e,))


if __name__ == "__main__":
    main()
