"""TML site library — pure-stdlib scraping of the 1TamilMV Invision forum.

Mirrors the parsing of the CloudStream TML provider (Kotlin) so the Kodi
addon shows the same sections, topics and links. No Kodi imports here, so
this module can be unit-tested outside Kodi.
"""

import json
import re
import time
import urllib.parse
import urllib.request
from html.parser import HTMLParser

BASE = "https://www.1tamilmv.solar"

FALLBACK_DOMAINS = [
    "https://www.1tamilmv.solar",
    "https://www.1tamilmv.cz",
    "https://1tamilmv.fi",
    "https://www.1tamilmv.onl",
    "https://1tamilmv.onl",
    "https://www.1tamilmv.lc",
    "https://1tamilmv.app",
]

# (url, display name) in the same order as the CloudStream TML main page.
SECTIONS = [
    (BASE + "/#top-releases", "Top Releases"),
    (BASE + "/#recently-added", "Recently Added"),
    (BASE + "/index.php?/forums/forum/10-predvd-dvdscr-cam-tc/", "PreDVD"),
    (BASE + "/index.php?/forums/forum/11-web-hd-itunes-hd-bluray/", "WEB-HD"),
    (BASE + "/index.php?/forums/forum/19-web-series-tv-shows/", "Web Series"),
    (BASE + "/index.php?/forums/forum/12-hd-rips-dvd-rips-br-rips/", "HD-Rips"),
    (BASE + "/index.php?/forums/forum/13-dvd9-dvd5/", "DVD9"),
    (BASE + "/index.php?/forums/forum/14-hdtv-sdtv-hdtv-rips/", "HDTV"),
    (BASE + "/index.php?/forums/forum/15-mp3-songs/", "MP3 Songs"),
    (BASE + "/index.php?/forums/forum/16-video-songs/", "Video Songs"),
    (BASE + "/index.php?/forums/forum/17-hollywood-movies-in-multi-audios/",
     "Hollywood Multi Audio"),
    (BASE + "/index.php?/forums/forum/18-cinema-news-reviews-general-videos/",
     "Cinema News"),
    (BASE + "/index.php?/forums/forum/102-watch-tamil-movies-online/",
     "Watch Online"),
]

UA = ("Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36")

_cache = {}
_live_base = [BASE]


# ---------------------------------------------------------------------------
# Networking
# ---------------------------------------------------------------------------

def _swap_domain(url, new_base):
    try:
        u = urllib.parse.urlsplit(url)
        b = urllib.parse.urlsplit(new_base)
        return urllib.parse.urlunsplit(
            (b.scheme, b.netloc, u.path, u.query, u.fragment))
    except Exception:
        return url


def fetch(url, timeout=20, binary=False):
    """GET a page, walking the fallback domains if the current one is dead.

    Returns text (or bytes when binary=True). Raises on total failure.
    """
    key = url.split("#")[0]
    now = time.time()
    hit = _cache.get(key)
    if hit and now - hit[0] < 60:
        return hit[1]
    candidates = [url]
    for d in FALLBACK_DOMAINS:
        s = _swap_domain(url, d)
        if s not in candidates:
            candidates.append(s)
    last = None
    for cand in candidates:
        try:
            req = urllib.request.Request(cand, headers={"User-Agent": UA})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                data = r.read()
            if binary:
                _cache[key] = (now, data)
                return data
            text = data.decode("utf-8", "replace")
            # Parked domains answer 200 with a registrar page — skip them.
            head = text[:4000].lower()
            if "domain for sale" in head or (
                    "registrar" in head and "1tamilmv" not in head):
                continue
            u = urllib.parse.urlsplit(cand)
            if u.scheme and u.netloc:
                _live_base[0] = "%s://%s" % (u.scheme, u.netloc)
            _cache[key] = (now, text)
            return text
        except Exception as e:  # try the next mirror
            last = e
    raise last if last else RuntimeError("unreachable: " + url)


def live_base():
    return _live_base[0]


# ---------------------------------------------------------------------------
# Minimal DOM (enough for the Invision selectors the provider uses)
# ---------------------------------------------------------------------------

VOID = {"br", "img", "hr", "meta", "link", "input", "source", "wbr"}


class El(object):
    __slots__ = ("tag", "attrs", "children", "parent")

    def __init__(self, tag, attrs, parent=None):
        self.tag = tag
        self.attrs = dict(attrs)
        self.children = []  # El or str
        self.parent = parent

    def text(self):
        out = []
        for c in self.children:
            out.append(c if isinstance(c, str) else c.text())
        return "".join(out)

    def iter(self):
        yield self
        for c in self.children:
            if isinstance(c, El):
                for d in c.iter():
                    yield d

    def find_all(self, tag=None, cls=None, attr_has=None):
        res = []
        for el in self.iter():
            if el is self:
                continue
            if tag and el.tag != tag:
                continue
            if cls and cls not in el.attrs.get("class", "").split():
                continue
            if attr_has:
                name, needle = attr_has
                if needle not in el.attrs.get(name, ""):
                    continue
            res.append(el)
        return res

    def find(self, tag=None, cls=None, attr_has=None):
        items = self.find_all(tag, cls, attr_has)
        return items[0] if items else None


class _Parser(HTMLParser):
    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.root = El("root", {})
        self.stack = [self.root]

    def handle_starttag(self, tag, attrs):
        el = El(tag, attrs, self.stack[-1])
        self.stack[-1].children.append(el)
        if tag not in VOID:
            self.stack.append(el)

    def handle_startendtag(self, tag, attrs):
        self.stack[-1].children.append(El(tag, attrs, self.stack[-1]))

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                break

    def handle_data(self, data):
        self.stack[-1].children.append(data)


def parse(html_text):
    p = _Parser()
    try:
        p.feed(html_text)
    except Exception:
        pass
    return p.root


def abs_url(href, page_url):
    return urllib.parse.urljoin(page_url, href or "")


# ---------------------------------------------------------------------------
# Titles
# ---------------------------------------------------------------------------

def clean_thread_title(raw):
    t = re.sub(r"\s*\|\s*1TamilMV.*$", "", raw or "", flags=re.I)
    t = re.sub(r"\s*-\s*1TamilMV.*$", "", t, flags=re.I)
    t = re.sub(r"\s+", " ", t).strip()
    bracket = t.find(" - [")
    if bracket > 8:
        t = t[:bracket].strip()
    return t.strip().rstrip("-").rstrip("–").strip()


def _looks_like_tag(s):
    s = (s or "").strip()
    return (s.startswith("[") or s.upper() == "MAGNET"
            or s.lower() == "watch online" or len(s) < 4)


def _title_from_slug(href):
    slug = href.split("/forums/topic/", 1)[-1] if "/forums/topic/" in href \
        else href.split("/threads/", 1)[-1]
    slug = re.sub(r"^\d+-", "", slug.strip("/"))
    slug = urllib.parse.unquote(slug)
    return re.sub(r"\s+", " ", slug.replace("-", " ")).strip()


TOPIC_RE = re.compile(r"/forums/topic/\d+[-/]|/threads/[^/]*\.?\d+")
WIDGET_TITLES = {"languages", "top releases this week", "recently added",
                 "trending", "latest posts", "popular topics"}


def _topic_title(a, href):
    attr_title = a.attrs.get("title", "").strip()
    if not _looks_like_tag(attr_title) and len(attr_title) >= 8:
        return clean_thread_title(attr_title)
    own = a.text().strip()
    if not _looks_like_tag(own) and len(own) >= 8:
        return clean_thread_title(own)
    el = a
    for _ in range(4):
        parent = el.parent
        if parent is None:
            break
        sibs = parent.children
        try:
            idx = sibs.index(el)
        except ValueError:
            idx = -1
        for j in range(idx - 1, -1, -1):
            sib = sibs[j]
            if isinstance(sib, El):
                prev = sib.text().strip()
                if len(prev) >= 8 and not _looks_like_tag(prev):
                    return clean_thread_title(prev)
                break
        el = parent
    return clean_thread_title(_title_from_slug(href))


def extract_threads(root, page_url):
    seen = set()
    out = []
    for a in root.find_all("a"):
        href = a.attrs.get("href", "")
        if "/forums/topic/" not in href and "/threads/" not in href:
            continue
        href = abs_url(href, page_url)
        if not TOPIC_RE.search(href):
            continue
        if "/page/" in href or "#" in href or "findComment" in href:
            continue
        if href in seen:
            continue
        seen.add(href)
        title = _topic_title(a, href)
        if len(title) < 4 or title.lower() in WIDGET_TITLES:
            continue
        out.append({"title": title, "url": href})
    return out


def extract_banger(root, page_url, key, limit=50):
    """Topics inside a homepage banger widget (TOP RELEASES / RECENTLY ADDED)."""
    container = None
    for div in root.find_all("div", cls="banger-container"):
        header = div.find(cls="banger-header")
        if header is not None and key.lower() in header.text().lower():
            container = div
            break
    if container is None:
        return []
    seen = set()
    out = []
    last_title = ""
    for strong in container.find_all("strong"):
        anchor = None
        for a in strong.find_all("a"):
            if "/forums/topic/" in a.attrs.get("href", ""):
                anchor = a
                break
        if anchor is None:
            t = clean_thread_title(strong.text().strip())
            if len(t) >= 8 and not _looks_like_tag(t):
                last_title = t
            continue
        href = abs_url(anchor.attrs.get("href", ""), page_url)
        if not TOPIC_RE.search(href) or "/page/" in href or "#" in href:
            continue
        if href in seen:
            continue
        seen.add(href)
        own = clean_thread_title(strong.text().strip())
        if len(own) >= 8 and not _looks_like_tag(own):
            title = own
        elif len(last_title) >= 8:
            title = last_title
        else:
            title = _topic_title(anchor, href)
        if len(title) < 4:
            continue
        out.append({"title": title, "url": href})
        if len(out) >= limit:
            break
    return out


# ---------------------------------------------------------------------------
# Topic page: first post, poster, links
# ---------------------------------------------------------------------------

def first_post(root):
    el = root.find("div", cls="cPost_contentWrap")
    if el is not None:
        return el
    for el in root.iter():
        if el.attrs.get("data-role") == "commentContent":
            return el
    el = root.find("div", cls="ipsType_richText")
    return el if el is not None else root


POSTER_SKIP = ("logo", "avatar", "torrborder", "utorrent", "smilie",
               "emoji", "vlcsnap", "snapshot", "screenshot")


def poster_from_post(post, page_url):
    for img in post.find_all("img"):
        src = img.attrs.get("src") or img.attrs.get("data-src") or ""
        if not src or src.startswith("data:"):
            continue
        if any(s in src.lower() for s in POSTER_SKIP):
            continue
        return abs_url(src, page_url)
    return None


def og_image(root, page_url):
    for el in root.iter():
        if el.tag == "meta" and el.attrs.get("property") == "og:image":
            content = el.attrs.get("content", "")
            if content:
                return abs_url(content, page_url)
    return None


def og_title(root):
    for el in root.iter():
        if el.tag == "meta" and el.attrs.get("property") == "og:title":
            content = el.attrs.get("content", "")
            if content:
                return content
    title_el = root.find("title")
    return title_el.text() if title_el is not None else ""


VIDEO_RE = re.compile(r"\.(mp4|mkv|avi|m3u8)(\?|$)", re.I)


def collect_links(post, page_url):
    """Every usable link in the first post, in post order.

    Returns dicts: url, label, kind in
    {direct_button, magnet, torrent, video, host}.
    Quality blocks are: <.torrent filename link> <MAGNET> <DIRECT LINK>;
    the filename text is remembered so DIRECT LINK inherits its label.
    """
    links = {}
    order = []
    block_label = ""
    for a in post.find_all("a"):
        href = (a.attrs.get("href") or "").strip()
        if not href or href.startswith("#"):
            continue
        href = abs_url(href, page_url) if not href.startswith("magnet:") \
            else href
        text = a.text().strip()
        label = text if text else href
        if href.startswith("magnet:") and len(label) < 12:
            m = re.search(r"[&?]dn=([^&]+)", href)
            if m:
                try:
                    label = urllib.parse.unquote_plus(m.group(1))
                except Exception:
                    pass
        # Screenshot image anchors are not downloads.
        if label == href and a.find("img") is not None and (
                "pixelbb" in href.lower() or "/image/" in href.lower()) \
                and not href.startswith("magnet:") \
                and "attachment.php" not in href:
            continue
        if len(label) > 25 and (".mkv" in label.lower()
                                or ".torrent" in label.lower()):
            block_label = label
        is_direct_button = ("download-button" in a.attrs.get("class", "")
                            or label.upper() == "DIRECT LINK")
        if is_direct_button:
            label = "DIRECT | " + (block_label or "Direct Link")
        is_magnet = href.startswith("magnet:")
        is_torrent = (href.endswith(".torrent") or "/attachments/" in href
                      or "attachment.php" in href)
        is_video = bool(VIDEO_RE.search(href))
        is_host = (href.startswith("http") and "1tamilmv" not in href
                   and "tamilmv." not in href and "facebook.com" not in href
                   and "twitter.com" not in href and "t.me" not in href
                   and "telegram" not in href)
        if not (is_magnet or is_torrent or is_video or is_host):
            continue
        if href in links:
            continue
        kind = ("magnet" if is_magnet else "torrent" if is_torrent
                else "direct_button" if is_direct_button
                else "video" if is_video else "host")
        item = {"url": href, "label": label, "kind": kind}
        links[href] = item
        order.append(item)
    # Direct links first, torrents/magnets last (same order as TML).
    def prio(it):
        if it["label"].startswith("DIRECT |"):
            return 0
        if VIDEO_RE.search(it["url"]):
            return 1
        if it["kind"] == "magnet":
            return 3
        if it["kind"] == "torrent":
            return 4
        return 2
    order.sort(key=prio)
    return order


# ---------------------------------------------------------------------------
# Series helpers
# ---------------------------------------------------------------------------

def episode_range(text):
    if not text:
        return None
    m = re.search(r"EP\s*\(?\s*(\d{1,4})\s*[-–]\s*(\d{1,4})", text, re.I)
    if m:
        a, b = int(m.group(1)), int(m.group(2))
        if 1 <= a <= b and b - a <= 500:
            return (a, b)
    m = re.search(r"S\d{1,2}\s*E(\d{1,4})\s*[-–]\s*E?(\d{1,4})", text, re.I)
    if m:
        a, b = int(m.group(1)), int(m.group(2))
        if 1 <= a <= b and b - a <= 500:
            return (a, b)
    m = re.search(r"S\d{1,2}\s*E(\d{1,4})", text, re.I)
    if m:
        n = int(m.group(1))
        if n >= 1:
            return (n, n)
    m = re.search(r"\bEP\s*\(?\s*(\d{1,4})\s*\)?", text, re.I)
    if m:
        n = int(m.group(1))
        if n >= 1:
            return (n, n)
    return None


def is_series(title):
    if not title:
        return False
    has_marker = (re.search(r"\bS\d{1,2}\b", title, re.I)
                  or re.search(r"\bSeason\s*\d{1,2}\b", title, re.I))
    if not has_marker:
        return False
    return (episode_range(title) is not None or "season" in title.lower()
            or "episode" in title.lower())


def season_of(title):
    m = re.search(r"\bS(\d{1,2})\b", title or "", re.I)
    if m:
        return int(m.group(1))
    m = re.search(r"Season\s*(\d{1,2})\b", title or "", re.I)
    if m:
        return int(m.group(1))
    return 1


def group_episode_batches(links, title):
    """Group links into {(range): [links]} like the TML provider."""
    batches = {}
    for link in links:
        r = episode_range(link["label"])
        if r is None:
            continue
        batches.setdefault(r, []).append(link)
    if not batches and links:
        r = episode_range(title)
        if r is not None:
            batches[r] = list(links)
    return batches


def fetch_topic_card(url, title):
    """Poster + details for one topic, for use on list items.

    One topic-page fetch (poster / fanart) plus a Cinemeta lookup (plot,
    rating, cast). Any failure returns whatever partial data was found.
    """
    card = {}
    try:
        root_el = parse(fetch(url, timeout=12))
        post = first_post(root_el)
        poster = og_image(root_el, url) or poster_from_post(post, url)
        if poster:
            card["poster"] = poster
            card["fanart"] = poster
        text = post.text().strip()
        if text:
            # Drop Telegram-promo boilerplate lines from the post text.
            lines = [ln.strip() for ln in text.splitlines()
                     if "telegram" not in ln.lower()]
            text = " ".join(ln for ln in lines if ln)
            text = re.sub(r"\s+", " ", text).strip()
            if text:
                card["plot"] = text[:600]
    except Exception:
        pass
    try:
        rich = fetch_rich(title, series=is_series(title))
        if rich:
            if rich.get("poster"):
                card["poster"] = rich["poster"]
            if rich.get("background"):
                card["fanart"] = rich["background"]
            if rich.get("plot"):
                card["plot"] = rich["plot"]
            if rich.get("rating"):
                card["rating"] = rich["rating"]
            if rich.get("duration"):
                card["duration"] = rich["duration"] * 60
            if rich.get("genres"):
                card["genre"] = " / ".join(rich["genres"])
            if rich.get("cast"):
                card["cast"] = rich["cast"]
            if rich.get("year"):
                card["year"] = rich["year"]
    except Exception:
        pass
    return card


# ---------------------------------------------------------------------------
# Search
# ---------------------------------------------------------------------------

def search(query):
    encoded = urllib.parse.quote_plus(query)
    try:
        html_text = fetch("%s/index.php?/search/&q=%s"
                          % (live_base(), encoded))
        results = extract_threads(parse(html_text), live_base())
        if results:
            return results
    except Exception:
        pass
    # Fallback: scan the homepage and match titles locally.
    tokens = query.lower().split()
    try:
        root = parse(fetch(live_base()))
        latest = extract_threads(root, live_base())
    except Exception:
        latest = []
    return [it for it in latest
            if all(t in it["title"].lower() for t in tokens)]


# ---------------------------------------------------------------------------
# Shortener resolution (DIRECT LINK chain)
# ---------------------------------------------------------------------------

def resolve_short_link(url):
    """cyberloom chain: page -> /out?t= link -> file page -> /files/ video."""
    try:
        hop1 = parse(fetch(url))
        out_url = None
        for a in hop1.find_all("a"):
            href = a.attrs.get("href", "")
            if "/out?t=" in href:
                out_url = abs_url(href, url)
                break
        if out_url is None:
            for a in hop1.find_all("a"):
                if "continue" in a.text().lower():
                    out_url = abs_url(a.attrs.get("href", ""), url)
                    break
        if not out_url:
            return None
        hop2 = parse(fetch(out_url))
        for a in hop2.find_all("a"):
            href = abs_url(a.attrs.get("href", ""), out_url)
            if "/files/" in href and VIDEO_RE.search(href):
                return href
        return None
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Cinemeta rich details (keyless, same strict matching as TML v7/OTM v9)
# ---------------------------------------------------------------------------

CINEMETA = "https://v3-cinemeta.strem.io"


def clean_movie_title(title):
    m = re.match(r"^(.*?)\s*\(((?:19|20)\d{2})\)", title or "")
    if m:
        name, year = m.group(1), m.group(2)
    else:
        name, year = (title or ""), None
        ym = re.search(r"\b((?:19|20)\d{2})\b", name)
        if ym:
            year = ym.group(1)
    name = re.sub(r"\b(Tamil|Telugu|Malayalam|Kannada|Hindi|TRUE|WEB-DL|"
                  r"WEBRip|HDRip|BluRay|PreDVD|HD|HQ|ESub|HC-ESub|Dubbed|"
                  r"ORG|DDP?\d(\.\d)?|AAC\d?(\.\d)?|HEVC|x264|x265|"
                  r"\d{3,4}p|4K|UHD|DVDRip|BDRip|CAM|TC)\b", " ", name,
                  flags=re.I)
    name = re.sub(r"[^A-Za-z0-9 ]+", " ", name)
    return re.sub(r"\s+", " ", name).strip(), year


def _norm(s):
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()


def _fetch_json(url, timeout=8):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


_rich_cache = {}


def fetch_rich(title, series=False):
    """Cinemeta details or None. Strict: record name must equal the cleaned
    title and the year must match when known; when several records verify,
    only an India-country record is trusted."""
    name, year = clean_movie_title(title)
    if not name:
        return None
    key = ("series" if series else "movie") + "|" + _norm(name) \
        + "|" + str(year)
    if key in _rich_cache:
        return _rich_cache[key]
    result = None
    try:
        mtype = "series" if series else "movie"
        q = urllib.parse.quote(name, safe="")
        data = _fetch_json("%s/catalog/%s/top/search=%s.json"
                           % (CINEMETA, mtype, q.replace("+", "%20")))
        metas = data.get("metas") or []
        candidates = []
        seen = set()
        for meta in metas:
            if _norm(meta.get("name")) != _norm(name):
                continue
            rel = str(meta.get("releaseInfo") or "")
            if year and year not in rel:
                continue
            imdb = meta.get("imdb_id") or meta.get("id")
            if not imdb or imdb in seen:
                continue
            seen.add(imdb)
            candidates.append(imdb)
            if len(candidates) >= 3:
                break
        verified = []
        for imdb in candidates:
            try:
                mdata = _fetch_json("%s/meta/%s/%s.json"
                                    % (CINEMETA, mtype, imdb))
            except Exception:
                continue
            meta = mdata.get("meta") or {}
            if _norm(meta.get("name")) != _norm(name):
                continue
            myear = str(meta.get("year") or "")
            if not myear:
                myear = str(meta.get("released") or "")[:4]
            if year and myear and year != myear:
                continue
            verified.append(meta)
        chosen = None
        if len(verified) == 1:
            chosen = verified[0]
        elif len(verified) > 1:
            for meta in verified:
                country = str(meta.get("country") or "")
                if "india" in country.lower():
                    chosen = meta
                    break
        if chosen is not None:
            rating = None
            try:
                rating = float(chosen.get("imdbRating"))
            except Exception:
                rating = None
            duration = None
            m = re.search(r"(\d+)", str(chosen.get("runtime") or ""))
            if m:
                duration = int(m.group(1))
            trailer = None
            for t in chosen.get("trailers") or []:
                if t.get("source"):
                    trailer = ("https://www.youtube.com/watch?v="
                               + str(t["source"]))
                    break
            result = {
                "plot": chosen.get("description"),
                "poster": chosen.get("poster"),
                "background": chosen.get("background"),
                "logo": chosen.get("logo"),
                "rating": rating,
                "duration": duration,
                "genres": chosen.get("genre") or [],
                "cast": (chosen.get("cast") or [])[:15],
                "year": int(myear) if (myear := str(
                    chosen.get("year") or chosen.get("released")
                    or "")[:4]).isdigit() else None,
                "trailer": trailer,
            }
    except Exception:
        result = None
    _rich_cache[key] = result
    return result
