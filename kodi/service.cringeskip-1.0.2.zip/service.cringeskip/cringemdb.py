"""CringeMDB lookup for the CringeMDB Skip Kodi service.

Pure stdlib (no Kodi imports) so it can be unit-tested outside Kodi.

find_guide(title, year) -> dict or None:
  {"slug": str, "not_safe": bool,
   "scenes": [{"start": int, "end": int, "category": str,
               "intensity": str, "desc": str}, ...]}
Returns None when CringeMDB has no matching page (or the page has
no verdict). Raises on network failure so callers can retry later.

Matching mirrors the 4KHUB CloudStream plugin: cleaned titles must
be equal, the year must be equal when known, and a one-year-off
candidate is accepted only when it is the single exact-title
candidate at that distance. When the year is unknown, the first
exact-title candidate wins.

Network: plain urllib first; if DNS resolution fails (some home
networks and VPNs refuse cringemdb.com), the host is resolved via
DNS-over-HTTPS (1.1.1.1, then 8.8.8.8 — reached by IP literal) and
the page is fetched from the resolved address with the real
hostname in the TLS handshake.
"""
import http.client
import json
import re
import socket
import ssl
import urllib.error
import urllib.parse
import urllib.request

BASE = "https://cringemdb.com"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")
TIMEOUT = 12

_cache = {}

SEXUAL_WORDS = ("sex", "nudity", "suggestive", "sexual")
VIOLENCE_WORDS = ("violence", "violent", "gore")


def clean_title(t):
    t = (t or "").lower()
    t = re.sub(r"[^a-z0-9 ]", "", t)
    return re.sub(r"\s+", " ", t).strip()


def parse_clock(s):
    """'1:25:27' / '09:58' / '56:12' -> seconds (int) or None."""
    if not s:
        return None
    s = s.strip().lstrip("to ").strip()
    parts = s.split(":")
    try:
        nums = [int(p) for p in parts]
    except ValueError:
        return None
    if len(nums) == 3:
        return nums[0] * 3600 + nums[1] * 60 + nums[2]
    if len(nums) == 2:
        return nums[0] * 60 + nums[1]
    if len(nums) == 1:
        return nums[0]
    return None


def parse_filename(name):
    """Best-effort (title, year) from a stream/file name.

    'Deadpool.2016.1080p.BluRay.x264.mp4' -> ('Deadpool', 2016)
    'Deadpool (2016).mp4'                  -> ('Deadpool', 2016)
    Returns None when no year is present.
    """
    if not name:
        return None
    base = name.replace("\\", "/").rsplit("/", 1)[-1]
    base = re.sub(r"\.[A-Za-z0-9]{2,4}$", "", base)
    m = re.search(r"(.*?)[. _\-\[]*\((19\d{2}|20\d{2})\)", base)
    if not m:
        m = re.search(r"(.*?)[. _\-\[]+(19\d{2}|20\d{2})(?:[. _\-\]]|$)", base)
    if not m:
        return None
    title = re.sub(r"[._]+", " ", m.group(1)).strip(" -_[]")
    title = re.sub(r"\s+", " ", title).strip()
    if not title:
        return None
    return title, int(m.group(2))


def is_sexual(category):
    c = (category or "").lower()
    return any(w in c for w in SEXUAL_WORDS)


def is_violence(category):
    c = (category or "").lower()
    return any(w in c for w in VIOLENCE_WORDS)


# ---------------------------------------------------------------- HTTP

def _doh_ips(host):
    endpoints = (
        "https://1.1.1.1/dns-query?name=%s&type=A" % host,
        "https://8.8.8.8/resolve?name=%s&type=A" % host,
    )
    for url in endpoints:
        try:
            req = urllib.request.Request(
                url, headers={"accept": "application/dns-json", "User-Agent": UA})
            with urllib.request.urlopen(req, timeout=8) as resp:
                data = json.loads(resp.read().decode("utf-8", "ignore"))
            ips = [a["data"] for a in data.get("Answer", [])
                   if a.get("type") == 1 and re.match(r"^\d+\.\d+\.\d+\.\d+$", a.get("data", ""))]
            if ips:
                return ips
        except Exception:
            pass
    return []


def _get_via_ip(ip, host, path):
    ctx = ssl.create_default_context()
    raw = socket.create_connection((ip, 443), timeout=TIMEOUT)
    try:
        sock = ctx.wrap_socket(raw, server_hostname=host)
    except Exception:
        raw.close()
        raise
    conn = http.client.HTTPSConnection(host, timeout=TIMEOUT)
    conn.sock = sock
    try:
        conn.request("GET", path, headers={"User-Agent": UA, "Host": host})
        resp = conn.getresponse()
        return resp.read().decode("utf-8", "ignore")
    finally:
        conn.close()


def http_get(url):
    """GET a cringemdb.com URL as text; DoH+IP fallback on failure."""
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            return resp.read().decode("utf-8", "ignore")
    except Exception:
        parts = urllib.parse.urlsplit(url)
        host = parts.hostname or "cringemdb.com"
        path = parts.path + ("?" + parts.query if parts.query else "")
        for ip in _doh_ips(host):
            try:
                return _get_via_ip(ip, host, path)
            except Exception:
                continue
        raise


# ---------------------------------------------------------------- lookup

def _strip_tags(x):
    return re.sub(r"<[^>]+>", "", x or "").strip()


def _unescape_json(s):
    return s.replace("\\/", "/").replace('\\"', '"').replace("\\\\", "\\")


def _search_candidates(title):
    url = BASE + "/search?term=" + urllib.parse.quote(title)
    text = http_get(url)
    pairs = re.findall(
        r'"movie"\s*:\s*"((?:[^"\\]|\\.)*)"\s*,\s*"slug"\s*:\s*"([^"]+)"',
        text)
    cands = []
    for movie, slug in pairs:
        m = re.match(r"^(.*?)\s*\((\d{4})", _unescape_json(movie))
        if not m:
            continue
        cands.append((clean_title(m.group(1)), int(m.group(2)), slug))
    return cands


def _parse_page(html_text, slug):
    vm = re.search(r'<p class="help-us">(.*?)</p>', html_text, re.S)
    verdict = _strip_tags(vm.group(1)) if vm else ""
    not_safe = "NOT SAFE" in verdict
    if not not_safe and "SAFE" not in verdict:
        return None
    scenes = []
    for block in re.findall(r'<article class="sg-scene"[^>]*>(.*?)</article>',
                            html_text, re.S):
        tm = re.search(r'<div class="sg-time">(.*?)</div>', block, re.S)
        start = end = None
        if tm:
            sm = re.search(r"<strong>(.*?)</strong>", tm.group(1), re.S)
            em = re.search(r"<span>(.*?)</span>", tm.group(1), re.S)
            start = parse_clock(_strip_tags(sm.group(1))) if sm else None
            end = parse_clock(_strip_tags(em.group(1))) if em else None
        h3 = re.search(r"<h3>(.*?)</h3>", block, re.S)
        category = ""
        intensity = ""
        if h3:
            im = re.search(r"<small>(.*?)</small>", h3.group(1), re.S)
            intensity = _strip_tags(im.group(1)) if im else ""
            category = _strip_tags(
                re.sub(r"<small>.*?</small>", "", h3.group(1), flags=re.S))
        dm = re.search(r"<p>(.*?)</p>", block, re.S)
        desc = _strip_tags(dm.group(1)) if dm else ""
        if start is None or end is None or end <= start:
            continue
        scenes.append({"start": start, "end": end, "category": category,
                       "intensity": intensity, "desc": desc})
    scenes.sort(key=lambda s: s["start"])
    return {"slug": slug, "not_safe": not_safe, "scenes": scenes}


def _title_attempts(title, year):
    """(title, year) queries to try, cleanest first.

    Players often hand over a raw release/topic title with no
    separate year ("Zodiac (2007) Tamil Dubbed 720p"), which the
    strict candidate match would miss. The year-split forms give
    the matcher a clean name to work with; candidate-side
    matching stays strict, so this cannot attach a wrong movie.
    """
    seen = set()
    attempts = [(title, year)]
    parsed = parse_filename(title or "")
    if parsed:
        attempts.append((parsed[0], year if year is not None else parsed[1]))
    m = re.match(r"^(.*?)\s*\((19\d{2}|20\d{2})\)", title or "")
    if m:
        attempts.append((m.group(1).strip(),
                         year if year is not None else int(m.group(2))))
    for t, y in attempts:
        k = (clean_title(t), y)
        if k not in seen and clean_title(t):
            seen.add(k)
            yield t, y


def find_guide(title, year):
    for attempt_title, attempt_year in _title_attempts(title, year):
        guide = _find_guide_strict(attempt_title, attempt_year)
        if guide is not None:
            return guide
    return None


def _find_guide_strict(title, year):
    key = (clean_title(title), year)
    if key in _cache:
        return _cache[key]
    cleaned = clean_title(title)
    cands = _search_candidates(title)
    slug = None
    for c_clean, c_year, c_slug in cands:
        if c_clean == cleaned and (year is None or c_year == year):
            slug = c_slug
            break
    if slug is None and year is not None:
        near = {c_slug for c_clean, c_year, c_slug in cands
                if c_clean == cleaned and abs(c_year - year) == 1}
        if len(near) == 1:
            slug = near.pop()
    result = None
    if slug:
        result = _parse_page(http_get(BASE + "/movie/" + slug), slug)
    _cache[key] = result
    return result
