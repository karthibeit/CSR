"""4KHUB site library — pure-stdlib scraping of 4KHDHub (4khdhub.one)
plus the greenmotors / HubCloud / HubDrive link resolution chain.

Mirrors the CloudStream 4KHUB provider (Kotlin) so the Kodi addon shows
the same sections, cards and links:

  - Listing pages render cards as `a.movie-card` (TMDB poster,
    `.movie-card-title`, `.movie-card-meta` with year / S01-S03).
  - Detail pages: `h1.page-title`, og:image poster, IMDb badge, genre
    badges, plot paragraph; movies have one `.download-item` per
    quality, series have `.episode-download-item` blocks plus
    `.download-item` season packs.
  - Every download button points at a greenmotors.club redirector.
    With the detail page as referer it 302s to greenmotors.cc, whose
    page hides the real HubCloud / HubDrive URL in a script blob:
    s('o','<blob>') -> base64 -> base64 -> ROT13 -> base64 -> JSON
    {"o": base64} -> the hub URL (verified live 2026-11-03).
  - HubCloud: drive page -> #download -> gamerxyt button page ->
    direct file links (FSL / S3 / Pixel / BuzzServer / hbplay).
  - HubDrive: the /file/ page links onward to the same HubCloud
    drive URL, so the HubCloud flow finishes the job.

No Kodi imports here, so this module can be unit-tested outside Kodi.
The one CloudStream trick that cannot be ported is the WebView
Cloudflare solve: when the mediator answers with a "Verify you are
human" page instead of the blob, resolve_link reports "cloudflare"
and the addon explains it to the user.
"""

import base64
import codecs
import re
import time
import urllib.parse
import urllib.request
import urllib.error
from html.parser import HTMLParser

import cringemdb

BASE = "https://4khdhub.one"

# (path, display name) — the site's own menu order, same as the
# CloudStream 4KHUB main page.
SECTIONS = [
    ("/", "Home"),
    ("/category/movies/", "Latest Movies"),
    ("/category/hindi-movies/", "Hindi Movies"),
    ("/category/english-movies/", "English Movies"),
    ("/category/series/", "Latest Episodes"),
    ("/category/korean-series/", "Korean"),
    ("/category/drama-series/", "Drama"),
    ("/category/hindi-series/", "Hindi Series"),
    ("/category/english-series/", "English Series"),
    ("/category/netflix/", "Netflix"),
    ("/category/amazon_prime_video/", "Amazon Prime Video"),
    ("/category/jiohotstar/", "JioHotstar"),
    ("/category/disney/", "Disney+"),
    ("/category/apple_tv/", "Apple TV+"),
    ("/category/hbo_max/", "HBO Max"),
    ("/category/hulu/", "Hulu"),
    ("/category/crave/", "Crave"),
    ("/category/anime/", "Anime"),
    ("/category/2160p-HDR/", "4K HDR"),
    ("/category/imdb/", "Top IMDb"),
]

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")

_cache = {}


# ---------------------------------------------------------------------------
# Networking
# ---------------------------------------------------------------------------

class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def fetch(url, referer=None, timeout=25, follow=True):
    """GET -> (status, final_url, headers dict with lower-case keys, text)."""
    headers = {"User-Agent": UA}
    if referer:
        headers["Referer"] = referer
    req = urllib.request.Request(url, headers=headers)
    opener = urllib.request.build_opener() if follow else \
        urllib.request.build_opener(_NoRedirect)
    try:
        with opener.open(req, timeout=timeout) as r:
            data = r.read()
            hd = {k.lower(): v for k, v in r.headers.items()}
            return r.status, r.geturl(), hd, data.decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        data = e.read() if e.fp else b""
        hd = {k.lower(): v for k, v in (e.headers.items() if e.headers else [])}
        return e.code, url, hd, data.decode("utf-8", "replace")


def fetch_cached(url, timeout=25):
    now = time.time()
    hit = _cache.get(url)
    if hit and now - hit[0] < 60:
        return hit[1]
    _, _, _, text = fetch(url, timeout=timeout)
    _cache[url] = (now, text)
    return text


def probe(url, referer=None, timeout=20):
    """Follow redirects but read nothing: (final_url, content_type)."""
    headers = {"User-Agent": UA}
    if referer:
        headers["Referer"] = referer
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.geturl(), r.headers.get_content_type() or ""
    except urllib.error.HTTPError as e:
        return (e.geturl() or url), ""
    except Exception:
        return url, ""


# ---------------------------------------------------------------------------
# Minimal DOM (enough for the selectors the provider uses)
# ---------------------------------------------------------------------------

VOID = {"br", "img", "hr", "meta", "link", "input", "source", "wbr"}


class El(object):
    __slots__ = ("tag", "attrs", "children", "parent")

    def __init__(self, tag, attrs, parent=None):
        self.tag = tag
        self.attrs = dict(attrs)
        self.children = []  # El or str
        self.parent = parent

    def text(self):
        out = []
        for c in self.children:
            out.append(c if isinstance(c, str) else c.text())
        return "".join(out)

    def iter(self):
        yield self
        for c in self.children:
            if isinstance(c, El):
                for d in c.iter():
                    yield d

    def find_all(self, tag=None, cls=None, attr_has=None):
        res = []
        for el in self.iter():
            if el is self:
                continue
            if tag and el.tag != tag:
                continue
            if cls and cls not in el.attrs.get("class", "").split():
                continue
            if attr_has:
                name, needle = attr_has
                if needle not in el.attrs.get(name, ""):
                    continue
            res.append(el)
        return res

    def find(self, tag=None, cls=None, attr_has=None):
        items = self.find_all(tag, cls, attr_has)
        return items[0] if items else None


class _Parser(HTMLParser):
    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.root = El("root", {})
        self.stack = [self.root]

    def handle_starttag(self, tag, attrs):
        el = El(tag, attrs, self.stack[-1])
        self.stack[-1].children.append(el)
        if tag not in VOID:
            self.stack.append(el)

    def handle_startendtag(self, tag, attrs):
        self.stack[-1].children.append(El(tag, attrs, self.stack[-1]))

    def handle_endtag(self, tag):
        for i in range(len(self.stack) - 1, 0, -1):
            if self.stack[i].tag == tag:
                del self.stack[i:]
                break

    def handle_data(self, data):
        self.stack[-1].children.append(data)


def parse(html_text):
    p = _Parser()
    try:
        p.feed(html_text)
    except Exception:
        pass
    return p.root


def abs_url(href, page_url):
    return urllib.parse.urljoin(page_url, href or "")


def _clean_ws(s):
    return re.sub(r"\s+", " ", (s or "").replace("\xa0", " ")).strip()


# ---------------------------------------------------------------------------
# Listings / search
# ---------------------------------------------------------------------------

def parse_cards(root, page_url):
    cards = []
    seen = set()
    for a in root.find_all("a", cls="movie-card"):
        href = abs_url(a.attrs.get("href", ""), page_url)
        if not href or href in seen:
            continue
        seen.add(href)
        title_el = a.find(cls="movie-card-title")
        title = _clean_ws(title_el.text()) if title_el else ""
        if not title:
            title = a.attrs.get("aria-label", "").replace(
                "details", "").strip()
        if not title:
            continue
        img = a.find("img")
        poster = None
        if img is not None:
            poster = img.attrs.get("data-src") or img.attrs.get("src")
            if poster:
                poster = abs_url(poster, page_url)
        meta_el = a.find(cls="movie-card-meta")
        meta = meta_el.text() if meta_el is not None else ""
        ym = re.search(r"(19|20)\d{2}", meta)
        year = int(ym.group(0)) if ym else None
        is_series = "-series-" in href or re.search(r"S\d{2}", meta)
        cards.append({"title": title, "url": href, "poster": poster,
                      "year": year, "is_series": bool(is_series)})
    return cards


def section_page(path, page):
    url = BASE + path
    if page > 1:
        url += "page/%d/" % page
    return url, parse_cards(parse(fetch_cached(url)), url)


def search(query):
    url = BASE + "/?s=" + urllib.parse.quote(query)
    return parse_cards(parse(fetch_cached(url)), url)


# ---------------------------------------------------------------------------
# Detail pages
# ---------------------------------------------------------------------------

def _download_buttons(item, label, page_url):
    links = []
    for a in item.find_all("a"):
        href = a.attrs.get("href", "")
        if not href.startswith("http") or "4khdhub" in href:
            continue
        host = _clean_ws(a.text()).replace("Download", "").strip() \
            or "Download"
        links.append({"url": href, "name": "%s — %s" % (label, host),
                      "ref": page_url})
    return links


def parse_detail(root, page_url):
    h1 = root.find("h1", cls="page-title")
    raw_title = _clean_ws(h1.text()) if h1 is not None else ""
    if not raw_title:
        for m in root.find_all("meta"):
            if m.attrs.get("property") == "og:title":
                raw_title = m.attrs.get("content", "").split(" - 4K")[0]
                break
    ym = re.search(r"\(((?:19|20)\d{2})\)", raw_title)
    year = int(ym.group(1)) if ym else None
    title = re.sub(r"\s*\((?:19|20)\d{2}\)\s*$", "", raw_title).strip()

    poster = None
    for m in root.find_all("meta"):
        if m.attrs.get("property") == "og:image":
            poster = m.attrs.get("content") or None
            break

    plot = None
    main = root.find(cls="content-main")
    if main is not None:
        for p in main.find_all("p", cls="mt-4"):
            t = _clean_ws(p.text())
            if len(t) > 40:
                plot = t
                break
    if not plot:
        for m in root.find_all("meta"):
            if m.attrs.get("property") == "og:description":
                plot = m.attrs.get("content") or None
                break

    score = None
    badge = root.find(cls="imdb-badge")
    if badge is not None:
        sm = re.search(r"\d+(\.\d+)?", badge.text())
        if sm:
            try:
                score = float(sm.group(0))
            except ValueError:
                score = None

    tags = []
    for b in root.find_all(cls="badge-outline"):
        t = _clean_ws(b.text())
        if t and t not in tags:
            tags.append(t)

    actors = []
    for item in root.find_all(cls="metadata-item"):
        t = item.text()
        if t.startswith("Stars:"):
            for name in t[len("Stars:"):].split(","):
                name = re.sub(r"\(.*?\)", "", name).strip()
                if name:
                    actors.append(name)
            break

    player = None
    for f in root.find_all("iframe"):
        src = f.attrs.get("src", "")
        if "videasy" in src:
            player = src
            break

    episode_items = root.find_all(cls="episode-download-item")
    is_series = "-series-" in page_url or bool(episode_items)

    detail = {"title": title, "year": year, "poster": poster,
              "plot": plot, "score": score, "tags": tags,
              "actors": actors, "player": player,
              "is_series": is_series, "links": [], "episodes": []}
    if not is_series:
        links = []
        for item in root.find_all(cls="download-item"):
            head = item.find(cls="download-header")
            label = _clean_ws(head.text()) if head is not None else ""
            links += _download_buttons(item, label or title, page_url)
        detail["links"] = links
        return detail

    episodes = {}
    for item in episode_items:
        fel = item.find(cls="episode-file-title")
        fname = _clean_ws(fel.text()) if fel is not None else ""
        m = re.search(r"S(\d{1,2})E(\d{1,3})", fname, re.I)
        if not m:
            continue
        key = (int(m.group(1)), int(m.group(2)))
        short = re.sub(r"\.(mkv|mp4|zip)$", "", fname, flags=re.I)
        episodes.setdefault(key, []).extend(
            _download_buttons(item, short, page_url))

    packs = {}
    for item in root.find_all(cls="download-item"):
        head = item.find(cls="download-header")
        label = _clean_ws(head.text()) if head is not None else ""
        sm = re.search(r"S(\d{1,2})\b", label)
        if not sm:
            continue
        season = int(sm.group(1))
        btns = _download_buttons(item, "Season Pack — " + label, page_url)
        if btns:
            packs.setdefault(season, []).extend(btns)
    for season, btns in packs.items():
        keys = [k for k in episodes if k[0] == season]
        first = min(keys) if keys else (season, 1)
        episodes.setdefault(first, [])
        episodes[first] = btns + episodes[first]

    detail["episodes"] = [
        {"season": s, "episode": e, "links": episodes[(s, e)]}
        for (s, e) in sorted(episodes.keys())]
    return detail


def load_detail(url):
    return parse_detail(parse(fetch_cached(url)), url)


# ---------------------------------------------------------------------------
# Parents Guide (CringeMDB) — same block format as the CloudStream plugin
# ---------------------------------------------------------------------------

def _fmt_clock(sec):
    sec = int(sec)
    h, rem = divmod(sec, 3600)
    m, s = divmod(rem, 60)
    if h:
        return "%d:%02d:%02d" % (h, m, s)
    return "%d:%02d" % (m, s)


def guide_block(title, year):
    """Rendered Parents Guide block for a movie, or None."""
    try:
        guide = cringemdb.find_guide(title, year)
    except Exception:
        return None
    if not guide:
        return None
    lines = []
    if guide["not_safe"]:
        lines.append("⚠ PARENTS GUIDE (CringeMDB) — "
                     "NOT SAFE to watch with kids")
    else:
        lines.append("✔ PARENTS GUIDE (CringeMDB) — "
                     "No flagged scenes reported")
    for sc in guide["scenes"]:
        line = "• %s–%s" % (_fmt_clock(sc["start"]), _fmt_clock(sc["end"]))
        if sc["category"]:
            line += " · " + sc["category"]
        if sc["intensity"]:
            line += " (%s)" % sc["intensity"]
        if sc["desc"]:
            line += " — " + sc["desc"]
        lines.append(line)
    lines.append("Full details: https://cringemdb.com/movie/"
                 + guide["slug"])
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Link resolution: greenmotors mediator -> HubCloud / HubDrive -> files
# ---------------------------------------------------------------------------

def _b64s(s):
    pad = "=" * (-len(s) % 4)
    return base64.b64decode(s + pad).decode("latin-1")


_BLOB_RE = re.compile(r"s\('o','([A-Za-z0-9+/=]+)'")


def _decode_blob(blob):
    try:
        layer2 = _b64s(_b64s(blob))
        json_text = _b64s(codecs.decode(layer2, "rot_13"))
        m = re.search(r'"o"\s*:\s*"([^"]+)"', json_text)
        if not m:
            return None
        url = _b64s(m.group(1))
        return url if url.startswith("http") else None
    except Exception:
        return None


def _is_challenge(text):
    low = text.lower()
    return ("verify you are human" in low or "just a moment" in low
            or "attention required" in low)


def resolve_redirector(url, referer):
    """greenmotors link -> (hub_url, challenged). Non-greenmotors
    URLs pass through unchanged."""
    if "greenmotors" not in url:
        return url, False

    def inspect(text):
        m = _BLOB_RE.search(text)
        if m:
            return _decode_blob(m.group(1))
        return None

    challenged = False
    # Attempt A: browser headers + detail-page referer, redirects on.
    try:
        _, _, _, text = fetch(url, referer=referer or (BASE + "/"))
        got = inspect(text)
        if got:
            return got, False
        challenged = challenged or _is_challenge(text)
    except Exception:
        pass
    # Attempt B: manual Location follow; the .cc step wants the
    # .club origin as referer.
    try:
        _, _, hd, text = fetch(url, referer=referer or (BASE + "/"),
                               follow=False)
        loc = hd.get("location")
        if loc:
            _, _, _, text2 = fetch(
                loc, referer="https://greenmotors.club/")
            got = inspect(text2)
            if got:
                return got, False
            challenged = challenged or _is_challenge(text2)
        else:
            got = inspect(text)
            if got:
                return got, False
            challenged = challenged or _is_challenge(text)
    except Exception:
        pass
    return None, challenged


def parse_quality(text):
    t = text or ""
    for pat, q in ((r"2160p|4K|UHD", 2160), (r"1440p", 1440),
                   (r"1080p", 1080), (r"720p", 720),
                   (r"480p", 480), (r"360p", 360)):
        if re.search(pat, t, re.I):
            return q
    return 0


def resolve_hubcloud(drive_url, label):
    """Drive page -> gamerxyt buttons -> direct file links.
    Returns [{name, url, quality}]."""
    out = []
    try:
        _, _, _, text = fetch(drive_url)
        root = parse(text)
        gamer_el = None
        for el in root.iter():
            if el.attrs.get("id") == "download":
                gamer_el = el
                break
        gamer = gamer_el.attrs.get("href", "") if gamer_el is not None \
            else ""
        if gamer and not gamer.startswith("http"):
            m = re.match(r"^(https?://[^/]+)", drive_url)
            gamer = (m.group(1) if m else "") + "/" + gamer.lstrip("/")
        if not gamer:
            return out
        _, _, _, gtext = fetch(gamer, referer=drive_url)
        groot = parse(gtext)
        header_el = groot.find(cls="card-header")
        header = header_el.text() if header_el is not None else ""
        qm = re.search(r"(\d{3,4})[pP]", header)
        quality = int(qm.group(1)) if qm else parse_quality(label)

        seen = set()

        def add(url, server):
            if url and url.startswith("http") and url not in seen:
                seen.add(url)
                out.append({"name": "%s [%s]" % (label, server),
                            "url": url, "quality": quality})

        for el in groot.find_all("a", cls="btn"):
            href = el.attrs.get("href", "")
            text_of = _clean_ws(el.text())
            if not href:
                continue
            low = text_of.lower()
            if "buzzserver" in low:
                try:
                    _, _, hd, _ = fetch(href + "/download",
                                        referer=href, follow=False)
                    if hd.get("hx-redirect"):
                        add(hd["hx-redirect"], "BuzzServer")
                except Exception:
                    pass
            elif "fsl" in low:
                add(href, "FSLv2 Server" if "fslv2" in low
                    else "FSL Server")
            elif "s3 server" in low:
                add(href, "S3 Server")
            elif "mega server" in low:
                add(href, "Mega Server")
            elif "download file" in low:
                add(href, "Download")
            elif "pixel" in low or "pixel." in href:
                final, ctype = probe(href, referer=gamer)
                if final != href and (".mkv" in final.lower()
                                      or ".mp4" in final.lower()
                                      or ctype.startswith("video")):
                    add(final, "Pixel Server")
                else:
                    add(href, "Pixel Server")
            elif "watch online" in low and "?u=" in href:
                try:
                    dec = _b64s(href.split("?u=")[1].split("&")[0])
                    if dec.startswith("http"):
                        add(dec, "Watch Online")
                except Exception:
                    pass
            else:
                # Unknown server button (e.g. a 10Gbps download
                # host): keep it when following it does NOT land on
                # an HTML page — these hosts hand the file straight
                # to whoever asks (a redirector landing page would
                # be text/html and is dropped).
                final, ctype = probe(href, referer=gamer)
                if final != href and "text/html" not in ctype:
                    add(final, text_of or "Server")
    except Exception:
        pass
    return out


def resolve_hubdrive(file_url):
    """A HubDrive /file/ page links onward to the HubCloud drive
    URL; find and return it (or None)."""
    try:
        _, _, _, text = fetch(file_url)
        for m in re.finditer(r'href="(https?://[^"]*hubcloud[^"]*/drive/[^"]+)"',
                             text):
            return m.group(1)
        for m in re.finditer(r'(https?://[^\s"\'<>]*hubcloud[^\s"\'<>]*/drive/[^\s"\'<>]+)',
                             text):
            return m.group(1)
    except Exception:
        pass
    return None


def resolve_link(link):
    """One download button -> (direct links, error).

    error is None on success, else one of:
    "cloudflare" (mediator served a human check), "mediator"
    (redirector did not decode), "hub" (hub page yielded nothing).
    """
    hub, challenged = resolve_redirector(link["url"], link.get("ref", ""))
    if not hub:
        return [], ("cloudflare" if challenged else "mediator")
    low = hub.lower()
    if "hubcloud" in low:
        links = resolve_hubcloud(hub, link["name"])
        return links, (None if links else "hub")
    if "hubdrive" in low or "hubcdn" in low:
        drive = resolve_hubdrive(hub)
        if drive:
            links = resolve_hubcloud(drive, link["name"])
            return links, (None if links else "hub")
        return [], "hub"
    # Some other host after the redirector: keep it if it is a
    # direct media file.
    final, ctype = probe(hub, referer=link.get("ref", ""))
    if ".mkv" in final.lower() or ".mp4" in final.lower() \
            or ctype.startswith("video"):
        return [{"name": link["name"], "url": final,
                 "quality": parse_quality(link["name"])}], None
    return [], "hub"
