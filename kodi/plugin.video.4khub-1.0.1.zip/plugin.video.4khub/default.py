"""4KHUB for Kodi — 4KHDHub sections, search and playback.

Port of the CloudStream 4KHUB plugin to a Kodi video addon. Download
buttons are resolved in the addon (greenmotors mediator -> HubCloud /
HubDrive -> direct file links) and played by Kodi itself. Movie pages
carry the CringeMDB Parents Guide at the top of the plot, like the
CloudStream plugin; playback hands Kodi the real title and year, so
the CringeMDB Skip service can identify the movie and auto-skip.
"""
import hashlib
import json
import re
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
PLUGIN_URL = sys.argv[0]

sys.path.append(ADDON.getAddonInfo("path") + "resources/lib")
import hubsite  # noqa: E402


def build_url(**params):
    return PLUGIN_URL + "?" + urllib.parse.urlencode(params)


# Directory listings and the play action run as separate
# invocations, so the art/info a detail page gathered cannot
# travel through the play URL (the plot alone can be long).
# They are stashed in window properties instead, keyed by the
# link payload and by title, and play() picks them up so the
# resolved item — and the player's Information panel — shows
# the poster and plot (Parents Guide included) instead of
# "Not available".
STASH_PREFIX = "fourkhub.item."


def _stash_key(text):
    return re.sub(r"[^a-z0-9]+", "_",
                  (text or "").lower()).strip("_")[:80]


def _payload_key(data):
    return "p." + hashlib.md5(
        (data or "").encode("utf-8", "replace")).hexdigest()[:16]


def _stash_put(key, art, info):
    if not key or (not art and not info):
        return
    try:
        xbmcgui.Window(10000).setProperty(
            STASH_PREFIX + key,
            json.dumps({"art": art or {}, "info": info or {}}))
    except Exception:
        pass


def _stash_get(key):
    if not key:
        return None
    try:
        raw = xbmcgui.Window(10000).getProperty(STASH_PREFIX + key)
        if raw:
            return json.loads(raw)
    except Exception:
        pass
    return None


def notify(msg):
    xbmcgui.Dialog().notification(
        "4KHUB", msg, xbmcgui.NOTIFICATION_INFO, 4000)


def add_dir(label, url, is_folder=True, art=None, info=None,
            playable=False):
    item = xbmcgui.ListItem(label=label)
    if art:
        item.setArt(art)
    if info:
        item.setInfo("video", info)
    if playable:
        item.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=is_folder)


def root():
    add_dir("Search", build_url(mode="search_keyboard"))
    for path, name in hubsite.SECTIONS:
        add_dir(name, build_url(mode="section", url=path, page=1))
    xbmcplugin.endOfDirectory(HANDLE)


def _card_item(card):
    art = None
    if card.get("poster"):
        art = {"poster": card["poster"], "thumb": card["poster"],
               "fanart": card["poster"]}
    info = {"title": card["title"]}
    if card.get("year"):
        info["year"] = card["year"]
    add_dir(card["title"],
            build_url(mode="detail", url=card["url"]),
            art=art, info=info)


def section(path, page):
    _, cards = hubsite.section_page(path, page)
    for card in cards:
        _card_item(card)
    if len(cards) >= 12:
        add_dir("Next page >>",
                build_url(mode="section", url=path, page=page + 1))
    xbmcplugin.endOfDirectory(HANDLE)


def search_keyboard():
    kb = xbmc.Keyboard("", "Search 4KHUB")
    kb.doModal()
    if not kb.isConfirmed():
        xbmcplugin.endOfDirectory(HANDLE)
        return
    query = kb.getText().strip()
    if not query:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    for card in hubsite.search(query):
        _card_item(card)
    xbmcplugin.endOfDirectory(HANDLE)


def _detail_info(d, plot):
    info = {"title": d["title"]}
    if plot:
        info["plot"] = plot
    if d.get("year"):
        info["year"] = d["year"]
    if d.get("score"):
        info["rating"] = d["score"]
    if d.get("tags"):
        info["genre"] = " / ".join(d["tags"])
    if d.get("actors"):
        info["cast"] = d["actors"]
    return info


def _play_item(link, title, year, art, info):
    payload = json.dumps(link)
    _stash_put(_payload_key(payload), art, info)
    _stash_put("t." + _stash_key(title), art, info)
    add_dir(link["name"],
            build_url(mode="play", data=payload, title=title,
                      year=year or ""),
            is_folder=False, art=art, info=info, playable=True)


def detail(url):
    d = hubsite.load_detail(url)
    art = {}
    if d.get("poster"):
        art = {"poster": d["poster"], "thumb": d["poster"],
               "fanart": d["poster"]}
    plot = d.get("plot")
    if not d["is_series"]:
        guide = hubsite.guide_block(d["title"], d.get("year"))
        if guide:
            plot = guide + ("\n\n" + plot if plot else "")
    info = _detail_info(d, plot)
    _stash_put("t." + _stash_key(d["title"]), art, info)
    if not d["is_series"]:
        if not d["links"]:
            add_dir("(No download links found)",
                    build_url(mode="detail", url=url), art=art,
                    info=info)
        for link in d["links"]:
            _play_item(link, d["title"], d.get("year"), art, info)
    else:
        if not d["episodes"]:
            add_dir("(No episodes found)",
                    build_url(mode="detail", url=url), art=art,
                    info=info)
        for ep in d["episodes"]:
            label = "S%02d E%02d" % (ep["season"], ep["episode"])
            payload = json.dumps(ep["links"])
            add_dir(label,
                    build_url(mode="episode", data=payload,
                              title=d["title"],
                              year=d.get("year") or ""),
                    art=art, info=info)
    xbmcplugin.endOfDirectory(HANDLE)


def episode(data_json, title, year):
    info = {"title": title}
    if year:
        try:
            info["year"] = int(year)
        except ValueError:
            pass
    stash = _stash_get("t." + _stash_key(title)) or {}
    art = stash.get("art")
    if stash.get("info"):
        merged = dict(stash["info"])
        merged.update(info)
        info = merged
    for link in json.loads(data_json):
        _play_item(link, title, year, art, info)
    xbmcplugin.endOfDirectory(HANDLE)


def play(data_json, title, year):
    link = json.loads(data_json)
    notify("Resolving links...")
    links, err = hubsite.resolve_link(link)
    if err == "cloudflare":
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok(
            "4KHUB",
            "The link step was blocked by a Cloudflare 'Verify you "
            "are human' check on this network.\n\n"
            "CloudStream solves this with its verify popup; Kodi has "
            "no verify popup, so the links cannot be unlocked here. "
            "It can help to try with the VPN off.")
        return
    if not links:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok(
            "4KHUB",
            "Could not resolve any playable link from this button. "
            "The site layout may have changed, or the file host is "
            "down — try another quality or server.")
        return
    chosen = links[0]
    if len(links) > 1:
        names = [l["name"] for l in links]
        idx = xbmcgui.Dialog().select("Choose server", names)
        if idx < 0:
            xbmcplugin.setResolvedUrl(
                HANDLE, False, xbmcgui.ListItem())
            return
        chosen = links[idx]
    item = xbmcgui.ListItem(path=chosen["url"])
    info = {"title": title}
    # Art and details gathered on the detail page ride along
    # via the stash, so the player's Information panel shows
    # the poster and plot instead of "Not available".
    stash = _stash_get(_payload_key(data_json)) \
        or _stash_get("t." + _stash_key(title))
    art = None
    if stash:
        art = stash.get("art") or None
        for k, v in (stash.get("info") or {}).items():
            if k != "title" and v:
                info[k] = v
    if year:
        try:
            info["year"] = int(year)
        except (TypeError, ValueError):
            pass
    if art:
        item.setArt(art)
    item.setInfo("video", info)
    xbmcplugin.setResolvedUrl(HANDLE, True, item)


def main():
    params = dict(urllib.parse.parse_qsl(sys.argv[2].lstrip("?")))
    mode = params.get("mode", "root")
    try:
        if mode == "root":
            root()
        elif mode == "section":
            section(params["url"], int(params.get("page", "1")))
        elif mode == "search_keyboard":
            search_keyboard()
        elif mode == "detail":
            detail(params["url"])
        elif mode == "episode":
            episode(params["data"], params.get("title", ""),
                    params.get("year", ""))
        elif mode == "play":
            play(params["data"], params.get("title", ""),
                 params.get("year", ""))
        else:
            root()
    except Exception as e:
        xbmc.log("4KHUB addon error: %r" % (e,), xbmc.LOGERROR)
        xbmcgui.Dialog().ok("4KHUB", "Something went wrong:\n%s" % (e,))


if __name__ == "__main__":
    main()
